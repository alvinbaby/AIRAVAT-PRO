/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.github.megatronking.stringfog;

public interface IStringFog {
    public String decrypt(String var1, String var2);

    public String encrypt(String var1, String var2);

    public boolean overflow(String var1, String var2);
}

