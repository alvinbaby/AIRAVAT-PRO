/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Base64
 *  java.io.UnsupportedEncodingException
 *  java.lang.Object
 *  java.lang.String
 */
package com.github.megatronking.stringfog.xor;

import android.util.Base64;
import com.github.megatronking.stringfog.IStringFog;
import java.io.UnsupportedEncodingException;

public final class StringFogImpl
implements IStringFog {
    public static final String CHARSET_NAME_UTF_8 = "UTF-8";

    public static String decrypt(String string2) {
        return new StringFogImpl().decrypt(string2, CHARSET_NAME_UTF_8);
    }

    private static byte[] xor(byte[] arrby, String string2) {
        int n = arrby.length;
        int n2 = string2.length();
        int n3 = 0;
        int n4 = 0;
        while (n4 < n) {
            if (n3 >= n2) {
                n3 = 0;
            }
            arrby[n4] = (byte)(arrby[n4] ^ string2.charAt(n3));
            ++n4;
            ++n3;
        }
        return arrby;
    }

    @Override
    public String decrypt(String string2, String string3) {
        try {
            String string4 = new String(StringFogImpl.xor(Base64.decode((String)string2, (int)2), string3), CHARSET_NAME_UTF_8);
            return string4;
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            return new String(StringFogImpl.xor(Base64.decode((String)string2, (int)2), string3));
        }
    }

    @Override
    public String encrypt(String string2, String string3) {
        try {
            String string4 = new String(Base64.encode((byte[])StringFogImpl.xor(string2.getBytes(CHARSET_NAME_UTF_8), string3), (int)2));
            return string4;
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            return new String(Base64.encode((byte[])StringFogImpl.xor(string2.getBytes(), string3), (int)2));
        }
    }

    @Override
    public boolean overflow(String string2, String string3) {
        return string2 != null && 4 * string2.length() / 3 >= 65535;
    }
}

