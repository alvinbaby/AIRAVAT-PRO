/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.text.ParseException
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.List
 *  java.util.Locale
 */
package sigma.male.sol;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class timedate {
    private static final Calendar calendar;
    private static final SimpleDateFormat simpleDateFormat;

    static {
        simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        calendar = Calendar.getInstance((Locale)new Locale("tr"));
    }

    public static List<String> getAllDaysOfTheWeek() {
        ArrayList arrayList = new ArrayList();
        calendar.setTime(new Date());
        calendar.set(7, 2);
        arrayList.add((Object)timedate.getTheDateInString(calendar.getTime()));
        int n = 1;
        while (n <= 6) {
            calendar.add(7, 1);
            arrayList.add((Object)timedate.getTheDateInString(calendar.getTime()));
            ++n;
        }
        return arrayList;
    }

    public static Date getCurrentDay() {
        Date date = new Date();
        simpleDateFormat.format(date);
        return date;
    }

    public static int getCurrentWeekNumber() {
        return Calendar.getInstance().get(3);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Date getDayOfTheWeek(Date date, int n) {
        calendar.setTime(date);
        if (n == 1) {
            calendar.set(7, 2);
            return calendar.getTime();
        }
        if (n != 7) return calendar.getTime();
        calendar.set(7, 1);
        calendar.add(7, 1);
        return calendar.getTime();
    }

    public static String getFirstDayOfMonth(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(5, 1);
        Date date2 = calendar.getTime();
        return new SimpleDateFormat("yyyy-MM-dd").format(date2);
    }

    public static String getFirstDayOfWeek(Date date) {
        return timedate.getTheDateInString(timedate.getMondayOfTheWeek(date));
    }

    public static String getLastDayOfMonth(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(5, calendar.getActualMaximum(5));
        Date date2 = calendar.getTime();
        return new SimpleDateFormat("yyyy-MM-dd").format(date2);
    }

    public static String getLastDayOfWeek(Date date) {
        return timedate.getTheDateInString(timedate.getSundayOfTheWeek(date));
    }

    public static Date getMondayOfTheWeek(Date date) {
        return timedate.getDayOfTheWeek(date, 1);
    }

    public static int getNumericLastDayOfMonth(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.getActualMaximum(5);
    }

    public static Date getSundayOfTheWeek(Date date) {
        return timedate.getDayOfTheWeek(date, 7);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static Date getTheDateInDate(String string2) {
        Date date;
        if (string2 == null) {
            return new Date();
        }
        try {
            Date date2;
            date = date2 = simpleDateFormat.parse(string2);
        }
        catch (ParseException parseException) {
            parseException.printStackTrace();
            date = null;
        }
        if (date == null) return new Date();
        return date;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String getTheDateInString(Date date) {
        if (date == null) {
            return "";
        }
        String string2 = simpleDateFormat.format(date);
        if (string2 != null) return string2;
        return "";
    }

    public static int getYear() {
        return Calendar.getInstance().get(1);
    }
}

