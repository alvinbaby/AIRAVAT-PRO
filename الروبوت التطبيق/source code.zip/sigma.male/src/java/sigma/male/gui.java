/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.io.BufferedReader
 *  java.io.File
 *  java.io.FileReader
 *  java.io.IOException
 *  java.io.Reader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package sigma.male;

import android.content.Context;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import sigma.male.FileUtil;

public class gui {
    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String audur(Context context) {
        String string2;
        StringBuilder stringBuilder = new StringBuilder();
        try {
            BufferedReader bufferedReader = new BufferedReader((Reader)new FileReader(new File(String.valueOf((Object)FileUtil.getPackageDataDir(context)) + "/audur.txt")));
            do {
                if ((string2 = bufferedReader.readLine()) != null) break block5;
                break;
            } while (true);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return stringBuilder.toString();
        }
        {
            block5 : {
                do {
                    return stringBuilder.toString();
                    break;
                } while (true);
            }
            stringBuilder.append(string2);
            continue;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String uuii(Context context) {
        String string2;
        StringBuilder stringBuilder = new StringBuilder();
        try {
            BufferedReader bufferedReader = new BufferedReader((Reader)new FileReader(new File(String.valueOf((Object)FileUtil.getPackageDataDir(context)) + "/uid.txt")));
            do {
                if ((string2 = bufferedReader.readLine()) != null) break block5;
                break;
            } while (true);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return stringBuilder.toString();
        }
        {
            block5 : {
                do {
                    return stringBuilder.toString();
                    break;
                } while (true);
            }
            stringBuilder.append(string2);
            continue;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String uuiip(Context context) {
        String string2;
        StringBuilder stringBuilder = new StringBuilder();
        try {
            BufferedReader bufferedReader = new BufferedReader((Reader)new FileReader(new File(String.valueOf((Object)FileUtil.getPackageDataDir(context)) + "/panel.txt")));
            do {
                if ((string2 = bufferedReader.readLine()) != null) break block5;
                break;
            } while (true);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return stringBuilder.toString();
        }
        {
            block5 : {
                do {
                    return stringBuilder.toString();
                    break;
                } while (true);
            }
            stringBuilder.append(string2);
            continue;
        }
    }
}

