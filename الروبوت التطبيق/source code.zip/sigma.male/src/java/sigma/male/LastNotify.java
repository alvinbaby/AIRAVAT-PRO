/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package sigma.male;

public class LastNotify {
    public String iconn;
    public String packageN;
    public String textN;
    public String ticker;
    public String timeN;
    public String titleN;
}

