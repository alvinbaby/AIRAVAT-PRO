/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Date
 */
package sigma.male.main;

import java.util.Date;

public class part2 {
    private String accessibilityEvent;
    private Date logoDate;
    private String msg;

    public String getAccessibilityEvent() {
        return this.accessibilityEvent;
    }

    public String getMsg() {
        return this.msg;
    }

    public Date getlogoDate() {
        return this.logoDate;
    }

    public void setAccessibilityEvent(String string2) {
        this.accessibilityEvent = string2;
    }

    public void setMsg(String string2) {
        this.msg = string2;
    }

    public void setlogoDate(Date date) {
        this.logoDate = date;
    }
}

