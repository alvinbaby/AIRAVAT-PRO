/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  java.io.IOException
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.security.SecureRandom
 *  java.security.cert.CertificateException
 *  java.security.cert.X509Certificate
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.Set
 *  java.util.concurrent.TimeUnit
 *  javax.net.ssl.HostnameVerifier
 *  javax.net.ssl.KeyManager
 *  javax.net.ssl.SSLContext
 *  javax.net.ssl.SSLSession
 *  javax.net.ssl.SSLSocketFactory
 *  javax.net.ssl.TrustManager
 *  javax.net.ssl.X509TrustManager
 *  okhttp3.Call
 *  okhttp3.Callback
 *  okhttp3.Headers
 *  okhttp3.OkHttpClient
 *  okhttp3.OkHttpClient$Builder
 *  okhttp3.Response
 *  okhttp3.ResponseBody
 */
package sigma.male;

import android.app.Activity;
import java.io.IOException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Response;
import okhttp3.ResponseBody;
import sigma.male.RequestNetwork;

public class RequestNetworkController {
    public static final String DELETE;
    public static final String GET;
    public static final String POST;
    public static final String PUT;
    private static final int READ_TIMEOUT = 25000;
    public static final int REQUEST_BODY = 1;
    public static final int REQUEST_PARAM = 0;
    private static final int SOCKET_TIMEOUT = 15000;
    private static RequestNetworkController mInstance;
    protected OkHttpClient client;

    static {
        GET = "GET";
        POST = "POST";
        PUT = "PUT";
        DELETE = "DELETE";
    }

    /*
     * WARNING - combined exceptions agressively - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private OkHttpClient getClient() {
        if (this.client == null) {
            OkHttpClient.Builder builder;
            builder = new OkHttpClient.Builder();
            try {
                TrustManager[] arrtrustManager = new TrustManager[1];
                X509TrustManager x509TrustManager = new X509TrustManager(){

                    public void checkClientTrusted(X509Certificate[] arrx509Certificate, String string2) throws CertificateException {
                    }

                    public void checkServerTrusted(X509Certificate[] arrx509Certificate, String string2) throws CertificateException {
                    }

                    public X509Certificate[] getAcceptedIssuers() {
                        return new X509Certificate[0];
                    }
                };
                arrtrustManager[0] = x509TrustManager;
                SSLContext sSLContext = SSLContext.getInstance((String)"TLS");
                sSLContext.init(null, arrtrustManager, new SecureRandom());
                builder.sslSocketFactory(sSLContext.getSocketFactory(), (X509TrustManager)arrtrustManager[0]);
                builder.connectTimeout(15000L, TimeUnit.MILLISECONDS);
                builder.readTimeout(25000L, TimeUnit.MILLISECONDS);
                builder.writeTimeout(25000L, TimeUnit.MILLISECONDS);
                builder.hostnameVerifier(new HostnameVerifier(){

                    public boolean verify(String string2, SSLSession sSLSession) {
                        return true;
                    }
                });
            }
            catch (Exception exception) {}
            this.client = builder.build();
        }
        return this.client;
    }

    public static RequestNetworkController getInstance() {
        Class<RequestNetworkController> class_ = RequestNetworkController.class;
        synchronized (RequestNetworkController.class) {
            if (mInstance == null) {
                mInstance = new RequestNetworkController();
            }
            RequestNetworkController requestNetworkController = mInstance;
            // ** MonitorExit[var2] (shouldn't be in output)
            return requestNetworkController;
        }
    }

    /*
     * Exception decompiling
     */
    public void execute(RequestNetwork var1_1, String var2_2, String var3_3, String var4_4, RequestNetwork.RequestListener var5_5) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [6[UNCONDITIONALDOLOOP]], but top level block is 0[TRYBLOCK]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

}

