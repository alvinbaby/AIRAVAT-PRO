/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.NotificationChannel
 *  android.app.NotificationManager
 *  android.app.PendingIntent
 *  android.app.Service
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.IBinder
 *  androidx.core.app.NotificationCompat
 *  androidx.core.app.NotificationCompat$Builder
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package sigma.male;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;
import sigma.male.MainActivity;

public class ForegroundService
extends Service {
    public static final String CHANNEL_ID = "ForegroundServiceChannel";
    Notification notification;

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, (CharSequence)"TURN THIS OFF \ud83d\udc49", 1);
            ((NotificationManager)this.getSystemService(NotificationManager.class)).createNotificationChannel(notificationChannel);
        }
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        super.onCreate();
    }

    public void onDestroy() {
        super.onDestroy();
    }

    /*
     * Enabled aggressive block sorting
     */
    public int onStartCommand(Intent intent, int n, int n2) {
        String string2 = intent.getStringExtra("inputExtra");
        PendingIntent.getActivity((Context)this, (int)0, (Intent)new Intent((Context)this, MainActivity.class), (int)0);
        if (Build.VERSION.SDK_INT >= 26) {
            this.createNotificationChannel();
            this.notification = new NotificationCompat.Builder((Context)this, CHANNEL_ID).setContentTitle((CharSequence)" ").setContentText((CharSequence)string2).setSmallIcon(2131165327).build();
        } else if (Build.VERSION.SDK_INT >= 21) {
            this.notification = new NotificationCompat.Builder((Context)this, CHANNEL_ID).setContentTitle((CharSequence)" ").setContentText((CharSequence)string2).setSmallIcon(2131165327).build();
        }
        this.startForeground(1, this.notification);
        return 2;
    }
}

