/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileOutputStream
 *  java.io.InputStream
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.security.Key
 *  javax.crypto.Cipher
 *  javax.crypto.CipherInputStream
 *  javax.crypto.spec.SecretKeySpec
 */
package sigma.male;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.spec.SecretKeySpec;

public class Aes {
    public static byte[] decrypt(byte[] arrby, byte[] arrby2) throws Exception {
        return Aes.decryptAes(Aes.getRawKey(arrby), arrby2);
    }

    private static byte[] decryptAes(byte[] arrby, byte[] arrby2) throws Exception {
        SecretKeySpec secretKeySpec = new SecretKeySpec(arrby, "AES");
        Cipher cipher = Cipher.getInstance((String)"AES");
        cipher.init(2, (Key)secretKeySpec);
        return cipher.doFinal(arrby2);
    }

    public static void decryptLarge(byte[] arrby, File file, File file2) throws Exception {
        SecretKeySpec secretKeySpec = new SecretKeySpec(Aes.getRawKey(arrby), "AES");
        Cipher cipher = Cipher.getInstance((String)"AES");
        cipher.init(2, (Key)secretKeySpec);
        FileInputStream fileInputStream = new FileInputStream(file);
        FileOutputStream fileOutputStream = new FileOutputStream(file2);
        byte[] arrby2 = new byte[4096];
        CipherInputStream cipherInputStream = new CipherInputStream((InputStream)fileInputStream, cipher);
        do {
            int n;
            if ((n = cipherInputStream.read(arrby2)) == -1) {
                fileOutputStream.close();
                cipherInputStream.close();
                file.delete();
                return;
            }
            fileOutputStream.write(arrby2, 0, n);
        } while (true);
    }

    public static byte[] encrypt(byte[] arrby, byte[] arrby2) throws Exception {
        return Aes.encryptAes(Aes.getRawKey(arrby), arrby2);
    }

    private static byte[] encryptAes(byte[] arrby, byte[] arrby2) throws Exception {
        SecretKeySpec secretKeySpec = new SecretKeySpec(arrby, "AES");
        Cipher cipher = Cipher.getInstance((String)"AES");
        cipher.init(1, (Key)secretKeySpec);
        return cipher.doFinal(arrby2);
    }

    public static void encryptLarge(byte[] arrby, File file, File file2) throws Exception {
        SecretKeySpec secretKeySpec = new SecretKeySpec(Aes.getRawKey(arrby), "AES");
        Cipher cipher = Cipher.getInstance((String)"AES");
        cipher.init(1, (Key)secretKeySpec);
        FileInputStream fileInputStream = new FileInputStream(file);
        FileOutputStream fileOutputStream = new FileOutputStream(file2);
        byte[] arrby2 = new byte[4096];
        CipherInputStream cipherInputStream = new CipherInputStream((InputStream)fileInputStream, cipher);
        do {
            int n;
            if ((n = cipherInputStream.read(arrby2)) == -1) {
                fileOutputStream.close();
                cipherInputStream.close();
                file.delete();
                return;
            }
            fileOutputStream.write(arrby2, 0, n);
        } while (true);
    }

    private static byte[] getRawKey(byte[] arrby) throws Exception {
        return new SecretKeySpec(arrby, "AES").getEncoded();
    }
}

