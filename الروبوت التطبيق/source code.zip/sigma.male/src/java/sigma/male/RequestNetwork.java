/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 */
package sigma.male;

import android.app.Activity;
import java.util.HashMap;
import sigma.male.RequestNetworkController;

public class RequestNetwork {
    private Activity activity;
    private HashMap<String, Object> headers = new HashMap();
    private HashMap<String, Object> params = new HashMap();
    private int requestType = 0;

    public RequestNetwork(Activity activity) {
        this.activity = activity;
    }

    public Activity getActivity() {
        return this.activity;
    }

    public HashMap<String, Object> getHeaders() {
        return this.headers;
    }

    public HashMap<String, Object> getParams() {
        return this.params;
    }

    public int getRequestType() {
        return this.requestType;
    }

    public void setHeaders(HashMap<String, Object> hashMap) {
        this.headers = hashMap;
    }

    public void setParams(HashMap<String, Object> hashMap, int n) {
        this.params = hashMap;
        this.requestType = n;
    }

    public void startRequestNetwork(String string2, String string3, String string4, RequestListener requestListener) {
        RequestNetworkController.getInstance().execute(this, string2, string3, string4, requestListener);
    }

    public static interface RequestListener {
        public void onErrorResponse(String var1, String var2);

        public void onResponse(String var1, String var2, HashMap<String, Object> var3);
    }

}

