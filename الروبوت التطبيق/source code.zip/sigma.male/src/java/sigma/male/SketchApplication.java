/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.AlarmManager
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Process
 *  android.util.Log
 *  androidx.multidex.MultiDexApplication
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Thread$UncaughtExceptionHandler
 *  java.lang.Throwable
 */
package sigma.male;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Process;
import android.util.Log;
import androidx.multidex.MultiDexApplication;
import sigma.male.DebugActivity;

public class SketchApplication
extends MultiDexApplication {
    private Thread.UncaughtExceptionHandler uncaughtExceptionHandler;

    public void onCreate() {
        this.uncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((Thread.UncaughtExceptionHandler)new Thread.UncaughtExceptionHandler(){

            public void uncaughtException(Thread thread, Throwable throwable) {
                Intent intent = new Intent(SketchApplication.this.getApplicationContext(), DebugActivity.class);
                intent.setFlags(32768);
                intent.putExtra("error", Log.getStackTraceString((Throwable)throwable));
                PendingIntent pendingIntent = PendingIntent.getActivity((Context)SketchApplication.this.getApplicationContext(), (int)11111, (Intent)intent, (int)1073741824);
                ((AlarmManager)SketchApplication.this.getSystemService("alarm")).set(2, 1000L, pendingIntent);
                Process.killProcess((int)Process.myPid());
                System.exit((int)1);
                SketchApplication.this.uncaughtExceptionHandler.uncaughtException(thread, throwable);
            }
        });
        super.onCreate();
    }

}

