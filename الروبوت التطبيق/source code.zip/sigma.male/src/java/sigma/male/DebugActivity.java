/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.os.Bundle
 *  android.util.Log
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package sigma.male;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

public class DebugActivity
extends Activity {
    private String[] exceptionMessages = new String[]{"Invalid string operation\n", "Invalid list operation\n", "Invalid arithmetical operation\n", "Invalid toNumber block operation\n", "Invalid intent operation"};
    private String[] exceptionTypes = new String[]{"StringIndexOutOfBoundsException", "IndexOutOfBoundsException", "ArithmeticException", "NumberFormatException", "ActivityNotFoundException"};

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    protected void onCreate(Bundle var1_1) {
        block10 : {
            block11 : {
                var2_2 = 0;
                super.onCreate(var1_1);
                var3_3 = this.getIntent();
                var4_4 = "";
                if (var3_3 != null) break block11;
                var5_8 = var4_4;
                break block10;
            }
            var10_5 = var3_3.getStringExtra("error");
            var11_6 = var10_5.split("\n");
            do lbl-1000: // 2 sources:
            {
                var13_7 = this.exceptionTypes.length;
                if (var2_2 >= var13_7) {
                    var5_8 = var4_4;
                    ** break block8
                }
                if (!var11_6[0].contains((CharSequence)this.exceptionTypes[var2_2])) break block9;
                var4_4 = this.exceptionMessages[var2_2];
                var14_11 = var11_6[0].indexOf(this.exceptionTypes[var2_2]);
                var15_12 = this.exceptionTypes[var2_2].length();
                var4_4 = String.valueOf((Object)var4_4) + var11_6[0].substring(var15_12 + var14_11, var11_6[0].length());
                var5_8 = var16_13 = String.valueOf((Object)var4_4) + "\n\nDetailed error message:\n" + var10_5;
                break;
            } while (true);
            catch (Exception var12_14) {}
lbl-1000: // 2 sources:
            {
                block9 : {
                    
                    var18_9 = var5_8.isEmpty();
                    if (var18_9) {
                        var5_8 = var10_5;
                    }
                    break block10;
                }
                ++var2_2;
                ** while (true)
            }
            ** GOTO lbl-1000
            catch (Exception var17_16) {
                var4_4 = var5_8;
                var12_15 = var17_16;
            }
lbl-1000: // 2 sources:
            {
                var5_8 = String.valueOf((Object)var4_4) + "\n\nError while getting error: " + Log.getStackTraceString((Throwable)var12_15);
            }
        }
        var6_10 = new AlertDialog.Builder((Context)this);
        var6_10.setTitle((CharSequence)"An error occurred");
        var6_10.setMessage((CharSequence)var5_8);
        var6_10.setPositiveButton((CharSequence)"End Application", new DialogInterface.OnClickListener(){

            public void onClick(DialogInterface dialogInterface, int n) {
                DebugActivity.this.finish();
            }
        });
        var6_10.create().show();
    }

}

