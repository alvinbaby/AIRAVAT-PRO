/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
public class $r8$backportedMethods$utility$Integer$2$compare {
    public static /* synthetic */ int compare(int n, int n2) {
        if (n == n2) {
            return 0;
        }
        if (n < n2) {
            return -1;
        }
        return 1;
    }
}

